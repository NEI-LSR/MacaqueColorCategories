clear all; close all

subNum = input('Enter subject number:  ');

C1vs=[];C2vs=[];C3vs=[];C4vs=[];C5vs=[];C6vs=[];C7vs=[];C8vs=[];C9vs=[];C10vs=[];
C11vs=[];C12vs=[];C13vs=[];C14vs=[];C15vs=[];C16vs=[];C17vs=[];C18vs=[];C19vs=[];
C20vs=[];C21vs=[];C22vs=[];C23vs=[];C24vs=[];

C1rx=[];C2rx=[];C3rx=[];C4rx=[];C5rx=[];C6rx=[];C7rx=[];C8rx=[];C9rx=[];C10rx=[];
C11rx=[];C12rx=[];C13rx=[];C14rx=[];C15rx=[];C16rx=[];C17rx=[];C18rx=[];C19rx=[];
C20rx=[];C21rx=[];C22rx=[];C23rx=[];C24rx=[];
    
totalCycles =[];    
sesNum = input('How many sessions would you like to analyze? ');
    for j = 1:sesNum
        disp(['Enter info for session ' num2str(j) ':']);
        sesYr(j) = input('Year (####): ');
        sesMo(j) = input('Month (#): ');
        sesDay(j) = input('Date (#): ');
        cycles = input('Cycle #s to analyze for this day (enter as an array w/ sq.br, [# # # etc.]): ');
        totalCycles = [totalCycles length(cycles)];
        cycNum(j) = length(cycles);
        
        for i = 1:length(cycles);
            cycleNum = cycles(i);
            folderName = [pwd '\subject' num2str(subNum) '\' num2str(sesYr(j)) '\' num2str(sesMo(j)) '\' num2str(sesDay(j)) '\cycle' num2str(cycleNum)];
            [A C1 C2 C3 C4 C5 C6 C7 C8 C9 C10 C11 C12 C13 C14 C15 C16 C17 C18 C19 C20 C21 C22 C23 C24] = analyzeData3_24([folderName '\cycle' num2str(cycleNum) 'Results']);
             [x1 x2 x3 x4 x5 x6 x7 x8 x9 x10 x11 x12 x13 x14 x15 x16 x17 x18 x19 x20 x21 x22 x23 x24] = analyzeData3b_24([folderName '\cycle' num2str(cycleNum) 'Results']);
        [rx1 rx2 rx3 rx4 rx5 rx6 rx7 rx8 rx9 rx10 rx11 rx12 rx13 rx14 rx15 rx16 rx17 rx18 rx19 rx20 rx21 rx22 rx23 rx24] = analyzeData3b_24rxn([folderName '\cycle' num2str(cycleNum) 'Results']);
        
            All(i) = A*100;
            C1c(i) = C1; 
            C2c(i) = C2;
            C3c(i) = C3;
            C4c(i) = C4;
            C5c(i) = C5;
            C6c(i) = C6;
            C7c(i) = C7;
            C8c(i) = C8;
            C9c(i) = C9;
            C10c(i) = C10;
            C11c(i) = C11;
            C12c(i) = C12;
            C13c(i) = C13;
            C14c(i) = C14;
            C15c(i) = C15;
            C16c(i) = C16;
            C17c(i) = C17;
            C18c(i) = C18;
            C19c(i) = C19;
            C20c(i) = C20;
            C21c(i) = C21;
            C22c(i) = C22;
            C23c(i) = C23;
            C24c(i) = C24;
        
C1vs = [C1vs; x1];
C2vs = [C2vs; x2];
C3vs = [C3vs; x3];
C4vs = [C4vs; x4];
C5vs = [C5vs; x5];
C6vs = [C6vs; x6];
C7vs = [C7vs; x7];
C8vs = [C8vs; x8];
C9vs = [C9vs; x9];
C10vs = [C10vs; x10];
C11vs = [C11vs; x11];
C12vs = [C12vs; x12];
C13vs = [C13vs; x13];
C14vs = [C14vs; x14];
C15vs = [C15vs; x15];
C16vs = [C16vs; x16];
C17vs = [C17vs; x17];
C18vs = [C18vs; x18];
C19vs = [C19vs; x19];
C20vs = [C20vs; x20];
C21vs = [C21vs; x21];
C22vs = [C22vs; x22];
C23vs = [C23vs; x23];
C24vs = [C24vs; x24];

C1rx = [C1rx; rx1];
C2rx = [C2rx; rx2];
C3rx = [C3rx; rx3];
C4rx = [C4rx; rx4];
C5rx = [C5rx; rx5];
C6rx = [C6rx; rx6];
C7rx = [C7rx; rx7];
C8rx = [C8rx; rx8];
C9rx = [C9rx; rx9];
C10rx = [C10rx; rx10];
C11rx = [C11rx; rx11];
C12rx = [C12rx; rx12];
C13rx = [C13rx; rx13];
C14rx = [C14rx; rx14];
C15rx = [C15rx; rx15];
C16rx = [C16rx; rx16];
C17rx = [C17rx; rx17];
C18rx = [C18rx; rx18];
C19rx = [C19rx; rx19];
C20rx = [C20rx; rx20];
C21rx = [C21rx; rx21];
C22rx = [C22rx; rx22];
C23rx = [C23rx; rx23];
C24rx = [C24rx; rx24];
        end
    end
    

    means = [mean(All) mean(C1c) mean(C2c) mean(C3c) mean(C4c) mean(C5c)...
        mean(C6c) mean(C7c) mean(C8c) mean(C9c) mean(C10c) mean(C11c)...
        mean(C12c) mean(C13c) mean(C14c) mean(C15c) mean(C16c) mean(C17c)...
        mean(C18c) mean(C19c) mean(C20c) mean(C21c) mean(C22c) mean(C23c) mean(C24c)];
        
    stds = [std(All) std(C1c) std(C2c) std(C3c) std(C4c) std(C5c)...
        std(C6c) std(C7c) std(C8c) std(C9c) std(C10c) std(C11c)...
        std(C12c) std(C13c) std(C14c) std(C15c) std(C16c) std(C17c)...
        std(C18c) std(C19c) std(C20c) std(C21c) std(C22c) std(C23c) std(C24c)];
    totalCycles = sum(totalCycles);    
    
    figure(98)
    set(gcf,'Color',[1 1 1]);
     X = 0:9;
        y = ones(1,10)*85;
        plot(X,y,'-.r')
        hold on
        Y2 = ones(1,10)*50;
        plot(X,Y2, '--g')
       
    errorbar(means,stds)
    set(gca,'XTick',1:24)
    set(gca,'XTickLabel',{'All','C1','C2','C3','C4', 'C5', 'C6', 'C7', 'C8', 'C9', 'C10', 'C11', 'C12', 'C13', 'C14', 'C15', 'C16', 'C17', 'C18', 'C19', 'C20', 'C21', 'C22', 'C23', 'C24'})
    ylabel('Percent Correct')
    xlabel('Sample Color (compared to all other colors)')
  % title(['Subject ' num2str(subNum) '; ' num2str(sesNum) ' Sessions; ' num2str(totalCycles) ' Cycles; ' num2str(24*totalCycles) ' trials/sample']);% ' - Session: ' num2str(sesYr) '/' num2str(sesMo) '/' num2str(sesDay) '; ' num2str(num) ' cycles']);
     ylim([0 100]);
     hold off


     C1vsM = mean(C1vs);  C2vsM = mean(C2vs); C3vsM = mean(C3vs);
     C4vsM = mean(C4vs); C5vsM = mean(C5vs); C6vsM = mean(C6vs);
     C7vsM = mean(C7vs); C8vsM = mean(C8vs); C9vsM = mean(C9vs);
     C10vsM = mean(C10vs); C11vsM = mean(C11vs); C12vsM = mean(C12vs);
     C13vsM = mean(C13vs); C14vsM = mean(C14vs); C15vsM = mean(C15vs);
     C16vsM = mean(C16vs); C17vsM = mean(C17vs); C18vsM = mean(C18vs);
     C19vsM = mean(C19vs); C20vsM = mean(C20vs); C21vsM = mean(C21vs);
     C22vsM = mean(C22vs); C23vsM = mean(C23vs); C24vsM = mean(C24vs);
     
          CvsMeans = [C1vsM; C2vsM; C3vsM; C4vsM; C5vsM; C6vsM; C7vsM; C8vsM; C9vsM; C10vsM;...
         C11vsM; C12vsM; C13vsM; C14vsM; C15vsM; C16vsM; C17vsM; C18vsM; C19vsM; C20vsM; C21vsM;...
         C22vsM; C23vsM; C24vsM];
     
     C1rxM = mean(C1rx);  C2rxM = mean(C2rx); C3rxM = mean(C3rx);
     C4rxM = mean(C4rx); C5rxM = mean(C5rx); C6rxM = mean(C6rx);
     C7rxM = mean(C7rx); C8rxM = mean(C8rx); C9rxM = mean(C9rx);
     C10rxM = mean(C10rx); C11rxM = mean(C11rx); C12rxM = mean(C12rx);
     C13rxM = mean(C13rx); C14rxM = mean(C14rx); C15rxM = mean(C15rx);
     C16rxM = mean(C16rx); C17rxM = mean(C17rx); C18rxM = mean(C18rx);
     C19rxM = mean(C19rx); C20rxM = mean(C20rx); C21rxM = mean(C21rx);
     C22rxM = mean(C22rx); C23rxM = mean(C23rx); C24rxM = mean(C24rx);
     
     CrxMeans = [C1rxM; C2rxM; C3rxM; C4rxM; C5rxM; C6rxM; C7rxM; C8rxM; C9rxM; C10rxM;...
         C11rxM; C12rxM; C13rxM; C14rxM; C15rxM; C16rxM; C17rxM; C18rxM; C19rxM; C20rxM; C21rxM;...
         C22rxM; C23rxM; C24rxM];
     
     CrxMeansOverall = mean(CrxMeans);
     CrxStdsOverall = std(CrxMeans);
     
     
     C1vsS = std(C1vs); 
       C2vsS = std(C2vs); 
         C3vsS = std(C3vs); 
           C4vsS = std(C4vs); 
             C5vsS = std(C5vs); 
               C6vsS = std(C6vs); 
                 C7vsS = std(C7vs); 
                   C8vsS = std(C8vs); 
                     C9vsS = std(C9vs); 
                       C10vsS = std(C10vs); 
                         C11vsS = std(C11vs); 
                           C12vsS = std(C12vs); 
                             C13vsS = std(C13vs); 
                               C14vsS = std(C14vs); 
                                 C15vsS = std(C15vs); 
                                   C16vsS = std(C16vs); 
                                     C17vsS = std(C17vs); 
                                       C18vsS = std(C18vs); 
                                         C19vsS = std(C19vs); 
                                           C20vsS = std(C20vs); 
                                             C21vsS = std(C21vs); 
                                               C22vsS = std(C22vs); 
                                                 C23vsS = std(C23vs); 
                                                   C24vsS = std(C24vs); 
                                                   
         CvsS = [C1vsS; C2vsS; C3vsS; C4vsS; C5vsS; C6vsS; C7vsS; C8vsS; C9vsS; C10vsS;...
         C11vsS; C12vsS; C13vsS; C14vsS; C15vsS; C16vsS; C17vsS; C18vsS; C19vsS; C20vsS; C21vsS;...
         C22vsS; C23vsS; C24vsS];
     
     
       C1rxS = std(C1rx); 
       C2rxS = std(C2rx); 
         C3rxS = std(C3rx); 
           C4rxS = std(C4rx); 
             C5rxS = std(C5rx); 
               C6rxS = std(C6rx); 
                 C7rxS = std(C7rx); 
                   C8rxS = std(C8rx); 
                     C9rxS = std(C9rx); 
                       C10rxS = std(C10rx); 
                         C11rxS = std(C11rx); 
                           C12rxS = std(C12rx); 
                             C13rxS = std(C13rx); 
                               C14rxS = std(C14rx); 
                                 C15rxS = std(C15rx); 
                                   C16rxS = std(C16rx); 
                                     C17rxS = std(C17rx); 
                                       C18rxS = std(C18rx); 
                                         C19rxS = std(C19rx); 
                                           C20rxS = std(C20rx); 
                                             C21rxS = std(C21rx); 
                                               C22rxS = std(C22rx); 
                                                 C23rxS = std(C23rx); 
                                                   C24rxS = std(C24rx); 
                                                   
         CrxS = [C1rxS; C2rxS; C3rxS; C4rxS; C5rxS; C6rxS; C7rxS; C8rxS; C9rxS; C10rxS;...
         C11rxS; C12rxS; C13rxS; C14rxS; C15rxS; C16rxS; C17rxS; C18rxS; C19rxS; C20rxS; C21rxS;...
         C22rxS; C23rxS; C24rxS];
                                                   
     
 figure(98)
set(gcf,'Color',[1 1 1]);

 errorbar(means(2:end),stds(2:end), 'LineWidth', 2)
set(gca,'XTick',1:24)
set(gca,'XTickLabel',{'C1','C2','C3','C4', 'C5', 'C6', 'C7', 'C8', 'C9','C10', 'C11', 'C12', 'C13', 'C14', 'C15', 'C16', 'C17', 'C18', 'C19', 'C20', 'C21', 'C22', 'C23', 'C24'})
% set(gca,'XTickLabel',{'Red','Orange','Yellow','Green', 'Cyan', 'Blue', 'Purple'})
ylabel('Percent Correct')
   %title(['Subject ' num2str(subNum) '; ' num2str(sesNum) ' Sessions; ' num2str(totalCycles) ' Cycles; ' num2str(24*totalCycles) ' trials/sample']);% ' - Session: ' num2str(sesYr) '/' num2str(sesMo) '/' num2str(sesDay) '; ' num2str(num) ' cycles']);
ylim([0 100]);
hold off

figure(99)
set(gcf,'Color',[1 1 1]);

 errorbar(CrxMeansOverall,CrxStdsOverall, 'LineWidth', 2)
set(gca,'XTick',1:24)
set(gca,'XTickLabel',{'C1','C2','C3','C4', 'C5', 'C6', 'C7', 'C8', 'C9','C10', 'C11', 'C12', 'C13', 'C14', 'C15', 'C16', 'C17', 'C18', 'C19', 'C20', 'C21', 'C22', 'C23', 'C24'})
% set(gca,'XTickLabel',{'Red','Orange','Yellow','Green', 'Cyan', 'Blue', 'Purple'})
ylabel('Rxn time [s]')
   %title(['Subject ' num2str(subNum) '; ' num2str(sesNum) ' Sessions; ' num2str(totalCycles) ' Cycles; ' num2str(24*totalCycles) ' trials/sample']);% ' - Session: ' num2str(sesYr) '/' num2str(sesMo) '/' num2str(sesDay) '; ' num2str(num) ' cycles']);
%ylim([0 100]);
hold off

figure(100)
for i = 1:24;
subplot(4,6,i)
X = 1:24;
Y = ones(1,24)*means(i+1);
plot(X,Y,'--k')
 hold on
%legend(['mean = ' num2str(means(i))])
stem(i,100,'r')
set(gcf,'Color',[1 1 1]);
vsM = CvsMeans(i,:);
vsS = CvsS(i,:);
if i == 1
    X = 2:24;
    plot(X,vsM)
elseif i == 24
    X = 1:23;
    plot(X,vsM)
else
vsM1 = vsM(1:(i-1));
vsM2 = vsM((i):23);
vsS1 = vsS(1:(i-1));
vsS2 = vsS(i:23);
X1 = 1:(i-1);
X2 = (i+1):24;
plot(X1,vsM1)
hold on
plot(X2,vsM2)
end
 set(gca,'XTick',(1:24))
 set(gca,'XTickLabel',{'C1','C2','C3','C4', 'C5', 'C6', 'C7', 'C8', 'C9','C10', 'C11', 'C12', 'C13', 'C14', 'C15', 'C16', 'C17', 'C18', 'C19', 'C20', 'C21', 'C22', 'C23', 'C24'});

ylim([0 100])
ylabel('Percent correct')
title(['C' num2str(i) 'vs. each color'])
xlabel('Color Compared to')
hold off
end

figure(101)  %need to fix the same way i fixed fig 100... look at how its broken into two plots to get a no data point at the sample color...
for i = 1:24;
subplot(4,6,i)
 X = 1:23;
% Y = ones(1,23)*means(i+1);
% plot(X,Y,'--k')
%  hold on
%legend(['mean = ' num2str(means(i))])
stem(i,100,'r')
hold on
set(gcf,'Color',[1 1 1]);
rxM = CrxMeans(i,:);
rxS = CrxS(i,:);
plot(X,rxM)
% errorbar(rxM,rxS)
set(gca,'XTick',(1:23)) %this is where it gets tricky..labeling the colors on the axis...!!!ROSA PAY ATTENTION HERE
label = {'C2','C3','C4', 'C5', 'C6', 'C7', 'C8', 'C9','C10', 'C11', 'C12', 'C13', 'C14', 'C15', 'C16', 'C17', 'C18', 'C19', 'C20', 'C21', 'C22', 'C23', 'C24';...
    'C1','C3','C4', 'C5', 'C6', 'C7', 'C8', 'C9','C10', 'C11', 'C12', 'C13', 'C14', 'C15', 'C16', 'C17', 'C18', 'C19', 'C20', 'C21', 'C22', 'C23', 'C24';...
    'C1','C2','C4', 'C5', 'C6', 'C7', 'C8', 'C9','C10', 'C11', 'C12', 'C13', 'C14', 'C15', 'C16', 'C17', 'C18', 'C19', 'C20', 'C21', 'C22', 'C23', 'C24';...
    'C1','C2','C3', 'C5', 'C6', 'C7', 'C8', 'C9','C10', 'C11', 'C12', 'C13', 'C14', 'C15', 'C16', 'C17', 'C18', 'C19', 'C20', 'C21', 'C22', 'C23', 'C24';...
    'C1','C2','C3','C4', 'C6', 'C7', 'C8', 'C9','C10', 'C11', 'C12', 'C13', 'C14', 'C15', 'C16', 'C17', 'C18', 'C19', 'C20', 'C21', 'C22', 'C23', 'C24';...
    'C1','C2','C3','C4', 'C5', 'C7', 'C8', 'C9','C10', 'C11', 'C12', 'C13', 'C14', 'C15', 'C16', 'C17', 'C18', 'C19', 'C20', 'C21', 'C22', 'C23', 'C24';...
    'C1','C2','C3','C4', 'C5', 'C6', 'C8', 'C9','C10', 'C11', 'C12', 'C13', 'C14', 'C15', 'C16', 'C17', 'C18', 'C19', 'C20', 'C21', 'C22', 'C23', 'C24';...
    'C1','C2','C3','C4', 'C5', 'C6', 'C7', 'C9','C10', 'C11', 'C12', 'C13', 'C14', 'C15', 'C16', 'C17', 'C18', 'C19', 'C20', 'C21', 'C22', 'C23', 'C24';...
    'C1','C2','C3','C4', 'C5', 'C6', 'C7', 'C8','C10', 'C11', 'C12', 'C13', 'C14', 'C15', 'C16', 'C17', 'C18', 'C19', 'C20', 'C21', 'C22', 'C23', 'C24';...
    'C1','C2','C3','C4', 'C5', 'C6', 'C7', 'C8', 'C9', 'C11', 'C12', 'C13', 'C14', 'C15', 'C16', 'C17', 'C18', 'C19', 'C20', 'C21', 'C22', 'C23', 'C24';...
    'C1','C2','C3','C4', 'C5', 'C6', 'C7', 'C8', 'C9','C10', 'C12', 'C13', 'C14', 'C15', 'C16', 'C17', 'C18', 'C19', 'C20', 'C21', 'C22', 'C23', 'C24';...
    'C1','C2','C3','C4', 'C5', 'C6', 'C7', 'C8', 'C9','C10', 'C11', 'C13', 'C14', 'C15', 'C16', 'C17', 'C18', 'C19', 'C20', 'C21', 'C22', 'C23', 'C24';...
    'C1','C2','C3','C4', 'C5', 'C6', 'C7', 'C8', 'C9','C10', 'C11', 'C12', 'C14', 'C15', 'C16', 'C17', 'C18', 'C19', 'C20', 'C21', 'C22', 'C23', 'C24';...
    'C1','C2','C3','C4', 'C5', 'C6', 'C7', 'C8', 'C9','C10', 'C11', 'C12', 'C13', 'C15', 'C16', 'C17', 'C18', 'C19', 'C20', 'C21', 'C22', 'C23', 'C24';...
    'C1','C2','C3','C4', 'C5', 'C6', 'C7', 'C8', 'C9','C10', 'C11', 'C12', 'C13', 'C14', 'C16', 'C17', 'C18', 'C19', 'C20', 'C21', 'C22', 'C23', 'C24';...
    'C1','C2','C3','C4', 'C5', 'C6', 'C7', 'C8', 'C9','C10', 'C11', 'C12', 'C13', 'C14', 'C15', 'C17', 'C18', 'C19', 'C20', 'C21', 'C22', 'C23', 'C24';...
    'C1','C2','C3','C4', 'C5', 'C6', 'C7', 'C8', 'C9','C10', 'C11', 'C12', 'C13', 'C14', 'C15', 'C16', 'C18', 'C19', 'C20', 'C21', 'C22', 'C23', 'C24';...
    'C1','C2','C3','C4', 'C5', 'C6', 'C7', 'C8', 'C9','C10', 'C11', 'C12', 'C13', 'C14', 'C15', 'C16', 'C17', 'C19', 'C20', 'C21', 'C22', 'C23', 'C24';...
    'C1','C2','C3','C4', 'C5', 'C6', 'C7', 'C8', 'C9','C10', 'C11', 'C12', 'C13', 'C14', 'C15', 'C16', 'C17', 'C18', 'C20', 'C21', 'C22', 'C23', 'C24';...
    'C1','C2','C3','C4', 'C5', 'C6', 'C7', 'C8', 'C9','C10', 'C11', 'C12', 'C13', 'C14', 'C15', 'C16', 'C17', 'C18', 'C19', 'C21', 'C22', 'C23', 'C24';...
    'C1','C2','C3','C4', 'C5', 'C6', 'C7', 'C8', 'C9','C10', 'C11', 'C12', 'C13', 'C14', 'C15', 'C16', 'C17', 'C18', 'C19', 'C20', 'C22', 'C23', 'C24';...
    'C1','C2','C3','C4', 'C5', 'C6', 'C7', 'C8', 'C9','C10', 'C11', 'C12', 'C13', 'C14', 'C15', 'C16', 'C17', 'C18', 'C19', 'C20', 'C21', 'C23', 'C24';...
    'C1','C2','C3','C4', 'C5', 'C6', 'C7', 'C8', 'C9','C10', 'C11', 'C12', 'C13', 'C14', 'C15', 'C16', 'C17', 'C18', 'C19', 'C20', 'C21', 'C22', 'C24';...
    'C1','C2','C3','C4', 'C5', 'C6', 'C7', 'C8', 'C9','C10', 'C11', 'C12', 'C13', 'C14', 'C15', 'C16', 'C17', 'C18', 'C19', 'C20', 'C21', 'C22', 'C23'};
set(gca,'XTickLabel',label(i,:));
% set(gca,'XTickLabel',{'Orange','Yellow','Green', 'Cyan', 'Blue', 'Purple'})
ylim([0.2 0.7])
ylabel('Rxn time [s]')
title(['C' num2str(i) 'vs. each color'])
xlabel('Color Compared to')
hold off
end


