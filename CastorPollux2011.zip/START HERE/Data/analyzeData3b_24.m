function [x1 x2 x3 x4 x5 x6 x7 x8 x9 x10 x11 x12 x13 x14 x15 x16 x17 x18 x19 x20 x21 x22 x23 x24] = analyzeData3b_24(resultsFile)
%                
% answer = input('Display all graphs? [1 for yes, 0 for no]  ');
answer = 1;

% [eyeTime eyeX eyeY] = textread(eyeFile,'%f %f %f','headerlines',15);  %13 change to 15 by rosa
% eyeData = [eyeTime eyeX eyeY];
% eyeData is now an array containing:
%     [  Time(sec.)    X Position    Y Position  ]
% for the entire session

numTrialsPerCycle = 552;
[A B C D E F G H I] = textread(resultsFile,'%u %f %f %f %u %u %u %u %u',552,...
                   'headerlines',(19));
trialInfo = [A B C D E F G H I];
compBias = mean(H)

%trialInfo is now an array containing:
% [Trialcount RedAmount GreenAmount BlueAmount sample# saturationLevel
% comparedTo corrMatchLoc incorrMatchLoc]
               
[a b c d e f g h i] = textread(resultsFile,'%u %u %u %u %f %u %f %u %f',...
                   'headerlines',(19 + numTrialsPerCycle + 3));
results = [a b c d e f g h i];
% results is now an array containing:
%     [  TrialNumber     HueNumber                SaturationAmount ...
%        CompareNumber   TimeOfMatchPresentation  HueChosen ...
%        TimeOfResponse  Correct?(bool) sec2time ]
% for each trial (completed and uncompleted)
totalTrials = length(results)
missTrials = totalTrials-552

% this array contains results for complete AND incomplete (due to
% breaks in fixation, etc.) trials. Incomplete trials have '9999' in 
% the sixth and eighth columns. this data is stored in the text file, so
% we'll get rid of the rows containing '9999'. 

results = results(results(:,8)~=9999,:);

% find percent correct
% disp(['Percent correct equals ' num2str(sum(results(:,8))/length(results)*100)]);
% A = sum(results(:,8))/length(results)*100;

% now results has only completed trials (but remember that the trial
% numbers are now no longer organized and may repeat if there are 
% multiple cycles in the session)

% now break results up based on hue of sample (column two) (including
% gray--saturation of 0)
c1 = results(results(:,2) == 1,:);
c1 = sortrows(c1,4);
c2 = results(results(:,2) == 2,:);
c2 = sortrows(c2,4);
c3 = results(results(:,2) == 3,:);
c3 = sortrows(c3,4);
c4 = results(results(:,2) == 4,:); 
c4 = sortrows(c4,4);
c5 = results(results(:,2) == 5,:);
c5 = sortrows(c5,4);
c6 = results(results(:,2) == 6,:);
c6 = sortrows(c6,4);
c7 = results(results(:,2) == 7,:);
c7 = sortrows(c7,4);
c8 = results(results(:,2) == 8,:);
c8 = sortrows(c8,4);
c9 = results(results(:,2) == 9,:);
c9 = sortrows(c9,4);
c10 = results(results(:,2) == 10,:);
c10 = sortrows(c10,4);
c11 = results(results(:,2) == 11,:);
c11 = sortrows(c11,4);
c12 = results(results(:,2) == 12,:);
c12 = sortrows(c12,4);
c13 = results(results(:,2) == 13,:);
c13 = sortrows(c13,4);
c14 = results(results(:,2) == 14,:);
c14 = sortrows(c14,4);
c15 = results(results(:,2) == 15,:);
c15 = sortrows(c15,4);
c16 = results(results(:,2) == 16,:);
c16 = sortrows(c16,4);
c17 = results(results(:,2) == 17,:);
c17 = sortrows(c17,4);
c18 = results(results(:,2) == 18,:);
c18 = sortrows(c18,4);
c19 = results(results(:,2) == 19,:);
c19 = sortrows(c19,4);
c20 = results(results(:,2) == 20,:);
c20 = sortrows(c20,4);
c21 = results(results(:,2) == 21,:);
c21 = sortrows(c21,4);
c22 = results(results(:,2) == 22,:);
c22 = sortrows(c22,4);
c23 = results(results(:,2) == 23,:);
c23 = sortrows(c23,4);
c24 = results(results(:,2) == 24,:);
c24 = sortrows(c24,4);

for i = 1:23
    x1(i) = c1(i,8)*100;
    x2(i) = c2(i,8)*100;
    x3(i) = c3(i,8)*100;
    x4(i) = c4(i,8)*100;
    x5(i) = c5(i,8)*100;
    x6(i) = c6(i,8)*100;
    x7(i) = c7(i,8)*100;
    x8(i) = c8(i,8)*100;
    x9(i) = c9(i,8)*100;
    x10(i) = c10(i,8)*100;
    x11(i) = c11(i,8)*100;
    x12(i) = c12(i,8)*100;
    x13(i) = c13(i,8)*100;
    x14(i) = c14(i,8)*100;
    x15(i) = c15(i,8)*100;
    x16(i) = c16(i,8)*100;
    x17(i) = c17(i,8)*100;
    x18(i) = c18(i,8)*100;
    x19(i) = c19(i,8)*100;
    x20(i) = c20(i,8)*100;
    x21(i) = c21(i,8)*100;
    x22(i) = c22(i,8)*100;
    x23(i) = c23(i,8)*100;
    x24(i) = c23(i,8)*100;
end

x = [x1; x2; x3; x4; x5; x6; x7; x8; x9; x10; x11; x12; x13; x14; x15; x16; x17; x18; x19; x20; x21; x22; x23; x24];

