function varargout = colorProgVer3GUI(varargin)
% colorProgVer3GUI M-file for colorProgVer3GUI.fig
%      colorProgVer3GUI, by itself, creates a new colorProgVer3GUI or raises the existing
%      singleton*.
%
%      H = colorProgVer3GUI returns the handle to a new colorProgVer3GUI or the handle to
%      the existing singleton*.
%
%      colorProgVer3GUI('CALLBACK',hObject,eventData,handles,...) calls the local
%      function named CALLBACK in colorProgVer3GUI.M with the given input arguments.
%
%      colorProgVer3GUI('Property','Value',...) creates a new colorProgVer3GUI or raises the
%      existing singleton*.  Starting from the left, property value pairs are
%      applied to the GUI before colorProgVer3GUI_OpeningFunction gets called.  An
%      unrecognized property name or invalid value makes property application
%      stop.  All inputs are passed to colorProgVer3GUI_OpeningFcn via varargin.
%
%      *See GUI Options on GUIDE's Tools menu.  Choose "GUI allows only one
%      instance to run (singleton)".
%
% See also: GUIDE, GUIDATA, GUIHANDLES

% Edit the above text to modify the response to help colorProgVer3GUI

% Last Modified by GUIDE v2.5 29-Oct-2009 22:34:33

%-------------------------------------------------------------------------%
%-------------------------------------------------------------------------%
% colorProgVer3.m
% 7/14/09 
% Modifications:
    % 1/7/09:
        % auxillary functions added
        % use of structures to publicize variables
    % 1/27/09:
        % use of figure to display eye tracker data as opposed to PTB
    % 4/19/09
        % use of while loops and GetSecs instead of toc
        % functions placed at bottom of file instead of in separate mfiles
        % restructuring, fewer variables, fewer conditionals
    % 7/14/09 
        % implements stimuli chosen from CIELUV coordinates
        % focal set for each hue, plus 3 saturation levels for each hue
        % that are equiluminant and equal saturation across hues for each
        % level
        % will begin to add in GUI features, if possible
        % will begin working on training steps as well
% 2AFC
%-------------------------------------------------------------------------%
%-------------------------------------------------------------------------%

% Begin initialization code - DO NOT EDIT
gui_Singleton = 1;
gui_State = struct('gui_Name',       mfilename, ...
                   'gui_Singleton',  gui_Singleton, ...
                   'gui_OpeningFcn', @colorProgVer3GUI_OpeningFcn, ...
                   'gui_OutputFcn',  @colorProgVer3GUI_OutputFcn, ...
                   'gui_LayoutFcn',  [] , ...
                   'gui_Callback',   []);
if nargin && ischar(varargin{1})
    gui_State.gui_Callback = str2func(varargin{1});
end

if nargout
    [varargout{1:nargout}] = gui_mainfcn(gui_State, varargin{:});
else
    gui_mainfcn(gui_State, varargin{:});
end
% End initialization code - DO NOT EDIT


% --- Executes just before colorProgVer3GUI is made visible.
function colorProgVer3GUI_OpeningFcn(hObject, eventdata, handles, varargin)
% This function has no output args, see OutputFcn.
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% varargin   command line arguments to colorProgVer3GUI (see VARARGIN)

% Choose default command line output for colorProgVer3GUI
handles.output = hObject;
handles.finish = 1;
handles.bar = 0;
handles.circle = 1;
handles.stimHeight = 100;
handles.stimWidth = 10;
handles.sec1time = .5;
handles.sec2short = .5;
handles.sec2long = .5;
handles.sec2time = .5;
handles.sec3time = 2;
handles.numMatches = 2;
handles.minSampleSat = 0;
handles.width = 1280/2;
handles.height = 960/2;
handles.fixLocx = handles.width;
handles.fixLocy = handles.height;
handles.sampleLocx = handles.width*(3/2);
handles.sampleLocy = handles.height/2;
handles.matchAngle = 30;
handles.xDisplacement = 320;
handles.match1Locx = handles.width-320*cosd(handles.matchAngle);
handles.match1Locy = handles.height-320*sind(handles.matchAngle);
handles.match2Locx = handles.width-320;
handles.match2Locy = handles.height;
handles.match3Locx = handles.width-320*cosd(handles.matchAngle);
handles.match3Locy = handles.height+320*sind(handles.matchAngle);
handles.fixBoxSize = 300;
handles.upperBoxSize = 300;
handles.lowerBoxSize = 300;
handles.sampleBoxSize = 300;
handles.fixColor = 200;
handles.sampleSide = 'right';
handles.maxSatMatch1 = 4;
handles.maxSatMatch2 = 4;
handles.subNum = 1;
handles.sesNum = 1;
handles.fixSize = 10;
handles.match1size = 100;
handles.match2size = 100;
handles.count = 1;
handles.numDrops = 1;
handles.eyeIsFixed = 1;
handles.allOK = 1;
handles.matchMX = [0 0 0];
handles.sampleDelay = 1;
handles.matchDelay = 1;
%-------------------------------------------------------------------------%
handles.orientation = 45;  
%-------------------------------------------------------------------------%

%-setup colors------------------------------------------------------------%
[colorMx grays whitePoint] = importColors2(handles.minSampleSat); % imports color matrix
rvalues = []; gvalues = []; bvalues = []; nums = []; amounts = []; compare = [];
for i = 1:length(colorMx)
    rvalues = [rvalues colorMx{i}.rvalues];     % red values
    gvalues = [gvalues colorMx{i}.gvalues];     % green values
    bvalues = [bvalues colorMx{i}.bvalues];     % blue values
    nums = [nums colorMx{i}.colorNum];          % color number
    amounts = [amounts colorMx{i}.amount];      % (rel.) saturation amount
    compare = [compare colorMx{i}.compareAgainst]; % color to compare to
end
stimmx = [rvalues; gvalues; bvalues; nums; amounts];
stimmx = [stimmx stimmx stimmx stimmx stimmx stimmx stimmx stimmx...
    stimmx stimmx stimmx stimmx stimmx stimmx stimmx stimmx stimmx...
    stimmx stimmx stimmx stimmx stimmx stimmx];
compareLine = [];
for i = 0:23  % 23 possible matches
    for j = 1:23  % 23 possible matches
        %for k = 1:4  % 4 sat. levels
            compareLine = [compareLine compare(j + 23*i)]; 
        %end
    end
end
% disp(size(stimmx));
% disp(size(compareLine));
stimmx = [stimmx; compareLine];
if handles.minSampleSat == 0
    stimmx = [stimmx grays];
end
stimorder = randperm(length(stimmx(1,:)));
for i = 1:6
    row = stimmx(i,:);
    row = row(stimorder);
    stimmx(i,:) = row;  % order stimuli for presentation
end
handles.stimMX = stimmx;
handles.trialTotal = length(handles.stimMX(1,:));

%-open display screen-----------------------------------------------------%
%--monkey's screen, PTB 
screen = 2;
[handles.wPtr, rect] = Screen('OpenWindow',screen,whitePoint);
%-initialize dio/ai-------------------------------------------------------%
board = 0;
handles.outlines = 20;
inlines = 7;
handles.dio = digitalio('mcc',board);
lines = addline(handles.dio,0:handles.outlines,'out');
%--eye tracking
handles.ai = analoginput('mcc',board);
addchannel(handles.ai,0:inlines);
set(handles.ai,'SamplesPerTrigger', inf);
start(handles.ai);
pause(.15);
handles = currentEyePos(handles);
handles.eyePos = zeros(80000,3);
handles.eyeCount = 1;
handles.eyeIsFixed = 1;
handles.eyeChoice = 0;
%-------------------------------------------------------------------------%

%--home screen, initialize eye position figure
%---(eye position matrices and fixation spot)
hold on
plot(handles.width*3/4, handles.height*3/4, '+b', 'MarkerSize',10);
axis([0 handles.width*3/2 0 handles.height*3/2]);
handles.eyeStore = plot(handles.eyePos(handles.eyeCount,2),...
                 handles.eyePos(handles.eyeCount,3),'.c');
set(handles.eyeStore,'Erase','xor');
handles.eyeCurrent = plot(0, 0,'.r','MarkerSize',20);
set(handles.eyeCurrent,'Erase','xor');
%---(sampleboxslider and matches)
handles.sampleSymbol = plot(0,0,'xg','MarkerSize',20);
set(handles.sampleSymbol,'Erase','xor');
handles.matchCorrect = plot(0,0,'xk','MarkerSize',20);
set(handles.matchCorrect,'Erase','xor');
handles.matchIncorrect = plot(0,0,'ok','MarkerSize',20);
set(handles.matchIncorrect,'Erase','xor');
handles.showCount = text(880,680,num2str(handles.count),'FontSize',12);
%-------------------------------------------------------------------------%

%-setup locations---------------------------------------------------------%
% if strcmp (handles.sampleSide, 'left')
%     handles.sampleLocx = handles.sampleLocx - handles.width;
% end
% if strcmp (handles.sampleSide, 'left')
%     handles.match1Locx = handles.match1Locx + handles.width;
% end
%handles.matchupdown = round(rand(1,handles.trialTotal)); % is match1 or match2 presented on top?
handles.matchlocs = rand(1,handles.trialTotal); % which positions are the matches in?
for i=1:length(handles.matchlocs)
    otherLoc = round(rand(1,1));
    if handles.matchlocs(i) < .33
        handles.matchlocs(i) = 1;
        if otherLoc, handles.incorMatchLocs(i) = 2;
        else handles.incorMatchLocs(i) = 3; end
    elseif handles.matchlocs(i) < .66
        handles.matchlocs(i) = 2;
        if otherLoc, handles.incorMatchLocs(i) = 3;
        else handles.incorMatchLocs(i) = 1; end
    else
        handles.matchlocs(i) = 3;
        if otherLoc, handles.incorMatchLocs(i) = 1;
        else handles.incorMatchLocs(i) = 2; end
    end
end
%handles.stimMX = [handles.stimMX; handles.matchupdown];

% handles.incorMatchLocs = handles.incorMatchLocs';
handles.stimMX = [handles.stimMX; handles.matchlocs; handles.incorMatchLocs];
%-record-keeping matrices-------------------------------------------------%
handles.stimuliRecord = [1:size(handles.stimMX,2); handles.stimMX(:,:)]; %stimuli presented
handles.responses = zeros(size(handles.stimMX,2),8); % was response correct?
handles.trialsToComplete = ones(size(handles.stimMX,2),1);
%handles.incorMatchLocs = zeros(1,size(handles.stimMX,2));
%-------------------------------------------------------------------------%
handles = plotBoxes1(handles);
handles.stimuliChanges = [GetSecs() handles.circle handles.stimHeight handles.stimWidth...
             handles.orientation handles.maxSatMatch1 handles.maxSatMatch2...
             handles.match1size handles.match2size handles.minSampleSat...
             handles.sec1time handles.sec3time];
%-------------------------------------------------------------------------%
figure(gcf);
% Update handles structure
guidata(hObject, handles);

% UIWAIT makes colorProgVer3GUI wait for user response (see UIRESUME)
% uiwait(handles.figure1);

% --- Outputs from this function are returned to the command line.
function varargout = colorProgVer3GUI_OutputFcn(hObject, eventdata, handles) 
% varargout  cell array for returning output args (see VARARGOUT);
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Get default command line output from handles structure
varargout{1} = handles.output;

function fixationtoggle_Callback(hObject, eventdata, handles)
wPtr = handles.wPtr; symbol = handles.sampleSymbol; 
%WaitSecs(.5);
handles = currentEyePos(handles);
handles = displayEyePos(handles);
[keyIsDown, secs, keyCode] = KbCheck;
while get(hObject,'Value')
    handles = plotBoxes2(handles);
    Screen('FillOval',wPtr,[255 255 255],[handles.fixLocx-handles.fixSize ...
                                          handles.fixLocy-handles.fixSize ...
                                          handles.fixLocx+handles.fixSize ...
                                          handles.fixLocy+handles.fixSize]);
    Screen('Flip',wPtr);
    set(symbol,'XData',handles.fixLocx*3/4,...
               'YData',3/4*(2*handles.height-handles.fixLocy));
    drawnow;
    handles = currentEyePos(handles);
    handles = displayEyePos(handles);
    handles = updateHandles(handles,' ',' ',' ');
    guidata(hObject, handles);
    [keyIsDown, secs, keyCode] = KbCheck;
    %--givejuice
    if keyCode(74)   %"j"
        handles = giveJuice(handles);
    end
end
%WaitSecs(.5);
handles.allOK = 0;
guidata(hObject,handles);
Screen('Flip',handles.wPtr);

function pausetoggle_Callback(hObject, eventdata, handles)
%WaitSecs(.5);
while get(hObject,'Value')
    Screen('Flip',handles.wPtr);
    [keyIsDown, secs, keyCode] = KbCheck;
    set(handles.sampleSymbol,'XData',0,'YData',0);
    drawnow
end
%WaitSecs(.5);
handles.allOK = 0;
Screen('FillOval',handles.wPtr,[handles.fixColor handles.fixColor handles.fixColor],...
    [handles.fixLocx-handles.fixSize ...
    handles.fixLocy-handles.fixSize ...
    handles.fixLocx+handles.fixSize ...
    handles.fixLocy+handles.fixSize]);
Screen('Flip',handles.wPtr);
guidata(hObject,handles);

function endbutton_Callback(hObject, eventdata, handles)
handles.finish = 0;
handles.allOK = 0;
handles.eyeIsFixed = 1;
Screen('Flip',handles.wPtr);
guidata(hObject, handles);

function resetbutton_Callback(hObject, eventdata, handles)
handles = updateHandles(handles,'new trial',' ',' ');
guidata(hObject, handles);
[colorMx grays whitePoint] = importColors2(handles.minSampleSat); % imports color matrix
rvalues = []; gvalues = []; bvalues = []; nums = []; amounts = []; compare = [];
for i = 1:24
    rvalues = [rvalues colorMx{i}.rvalues];     % red values
    gvalues = [gvalues colorMx{i}.gvalues];     % green values
    bvalues = [bvalues colorMx{i}.bvalues];     % blue values
    nums = [nums colorMx{i}.colorNum];          % color number
    amounts = [amounts colorMx{i}.amount];      % percentage intensity
    compare = [compare colorMx{i}.compareAgainst]; % color to compare to
end
stimmx = [rvalues; gvalues; bvalues; nums; amounts];
stimmx = [stimmx stimmx stimmx stimmx stimmx stimmx stimmx stimmx...
    stimmx stimmx stimmx stimmx stimmx stimmx stimmx stimmx stimmx...
    stimmx stimmx stimmx stimmx stimmx stimmx];
compareLine = [];
for i = 0:23  % 6 possible matches
    for j = 1:23  % 6 possible matches
%         for k = 1:4  % 4 sat. levels
            compareLine = [compareLine compare(j + 23*i)]; 
%         end
    end
end
stimmx = [stimmx; compareLine];
if handles.minSampleSat == 0
    stimmx = [stimmx grays];
end
stimorder = randperm(length(stimmx(1,:)));
for i = 1:6
    row = stimmx(i,:);
    row = row(stimorder);
    stimmx(i,:) = row;  % order stimuli for presentation
end
handles.stimMX = stimmx;
handles.trialTotal = length(handles.stimMX(1,:));
handles.eyePos = zeros(80000,3);
handles.eyeCount = 1;
handles.eyeIsFixed = 1;
handles.eyeChoice = 0;
handles.count = 1;
handles.finish = 1;
handles.allOK = 1;
%handles.matchupdown = round(linspace(0,1,handles.trialTotal)); % 50/50
%handles.matchupdown = round(linspace(.3,1,handles.trialTotal)); % on bottom more often
%handles.matchupdown = round(linspace(0,.7,handles.trialTotal)); % top more often
%handles.matchupdown = handles.matchupdown(stimorder);
% handles.matchlocs = linspace(0,1,handles.trialTotal); % which positions are the matches in?
% handles.matchlocs = handles.matchlocs(stimorder);
% otherLoc = round(rand(1,1));
% handles.incorMatchLocs = zeros(1,length(handles.matchlocs));
% for i=1:length(handles.matchlocs)
%     if handles.matchlocs(i) < .33
%         handles.matchlocs(i) = 1;
%         if otherLoc, handles.incorMatchLocs(i) = 2;
%         else handles.incorMatchLocs(i) = 3; end
%     elseif handles.matchlocs(i) < .66
%         handles.matchlocs(i) = 2;
%         if otherLoc, handles.incorMatchLocs(i) = 3;
%         else handles.incorMatchLocs(i) = 1; end
%     else
%         handles.matchlocs(i) = 3;
%         if otherLoc, handles.incorMatchLocs(i) = 1;
%         else handles.incorMatchLocs(i) = 2; end
%     end
% end
handles.incorMatchLocs = [];
handles.matchlocs = rand(1,handles.trialTotal); % which positions are the matches in?
for i=1:length(handles.matchlocs)
    otherLoc = round(rand(1,1));
    if handles.matchlocs(i) < .33
        handles.matchlocs(i) = 1;
        if otherLoc, handles.incorMatchLocs(i) = 2;
        else handles.incorMatchLocs(i) = 3; end
    elseif handles.matchlocs(i) < .66
        handles.matchlocs(i) = 2;
        if otherLoc, handles.incorMatchLocs(i) = 3;
        else handles.incorMatchLocs(i) = 1; end
    else
        handles.matchlocs(i) = 3;
        if otherLoc, handles.incorMatchLocs(i) = 1;
        else handles.incorMatchLocs(i) = 2; end
    end
end
%handles.stimMX = [handles.stimMX; handles.matchupdown];
handles.stimMX = [handles.stimMX; handles.matchlocs; handles.incorMatchLocs];
%-record-keeping matrices-------------------------------------------------%
handles.stimuliRecord = [1:size(handles.stimMX,2); handles.stimMX(:,:)]; %stimuli presented
handles.responses = zeros(size(handles.stimMX,2),9); % was response correct?
handles.trialsToComplete = ones(size(handles.stimMX,2),1);
%handles.incorMatchLocs = zeros(1,size(handles.stimMX,2));
%-------------------------------------------------------------------------%
%handles = createPath(handles);
%handles.filenameEye = ['cycle' num2str(handles.cycleNum) 'EyeData'];
%handles.filenameResults = ['cycle' num2str(handles.cycleNum) 'Results'];
%handles.filenameStimuli = ['cycle' num2str(handles.cycleNum) 'Stimuli'];
%handles = createTextFiles(handles);
%handles.writeFrequency = 5;
handles = plotBoxes2(handles);
handles.stimuliChanges = [GetSecs() handles.circle handles.stimHeight handles.stimWidth...
             handles.orientation handles.maxSatMatch1 handles.maxSatMatch2...
             handles.match1size handles.match2size handles.minSampleSat...
             handles.sec1time handles.sec3time];
guidata(hObject, handles);

function closebutton_Callback(hObject, eventdata, handles)
%-clean up----------------------------------------------------------------%
handles = writeData(handles);
handles = updateHandles(handles,' ','erase',' ');
guidata(hObject, handles);
stop(handles.ai);
Screen('Close',handles.wPtr);
close all; %clc;
fclose('all');
cd('C:\Documents and Settings\admin\Desktop\colorProgVer3b');

function barradiobutton_Callback(hObject, eventdata, handles)
handles.bar = get(hObject,'Value');
handles.circle = 0;
handles.stimuliChanges = [handles.stimuliChanges; 
            [GetSecs() handles.circle handles.stimHeight handles.stimWidth...
             handles.orientation handles.maxSatMatch1 handles.maxSatMatch2...
             handles.match1size handles.match2size handles.minSampleSat...
             handles.sec1time handles.sec3time]];
guidata(hObject, handles);

function circleradiobutton_Callback(hObject, eventdata, handles)
handles.circle = get(hObject,'Value');
handles.bar = 0;
handles.stimuliChanges = [handles.stimuliChanges; 
            [GetSecs() handles.circle handles.stimHeight handles.stimWidth...
             handles.orientation handles.maxSatMatch1 handles.maxSatMatch2...
             handles.match1size handles.match2size handles.minSampleSat...
             handles.sec1time handles.sec3time]];
guidata(hObject, handles);

function heightedit_Callback(hObject, eventdata, handles)
handles.stimHeight = str2double(get(hObject,'String'));
handles.stimuliChanges = [handles.stimuliChanges; 
            [GetSecs() handles.circle handles.stimHeight handles.stimWidth...
             handles.orientation handles.maxSatMatch1 handles.maxSatMatch2...
             handles.match1size handles.match2size handles.minSampleSat...
             handles.sec1time handles.sec3time]];
guidata(hObject, handles);
function heightedit_CreateFcn(hObject, eventdata, handles)
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

function widthedit_Callback(hObject, eventdata, handles)
handles.stimWidth = str2double(get(hObject,eventdata,handles));
handles.stimuliChanges = [handles.stimuliChanges; 
            [GetSecs() handles.circle handles.stimHeight handles.stimWidth...
             handles.orientation handles.maxSatMatch1 handles.maxSatMatch2...
             handles.match1size handles.match2size handles.minSampleSat...
             handles.sec1time handles.sec3time]];
guidata(hObject, handles);
function widthedit_CreateFcn(hObject, eventdata, handles)
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

function numdropspulldown_Callback(hObject, eventdata, handles)
contents = get(hObject,'String');
handles.numDrops = str2double(contents{get(hObject,'Value')});
guidata(hObject,handles);
function numdropspulldown_CreateFcn(hObject, eventdata, handles)
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

function sec1edit_Callback(hObject, eventdata, handles)
handles.sec1time = str2double(get(hObject,'String'));
handles.stimuliChanges = [handles.stimuliChanges; 
            [GetSecs() handles.circle handles.stimHeight handles.stimWidth...
             handles.orientation handles.maxSatMatch1 handles.maxSatMatch2...
             handles.match1size handles.match2size handles.minSampleSat...
             handles.sec1time handles.sec3time]];
guidata(hObject, handles);
function sec1edit_CreateFcn(hObject, eventdata, handles)
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

function sec2edit_Callback(hObject, eventdata, handles)
handles.sec2short = str2double(get(hObject,'String'));
guidata(hObject, handles);
function sec2edit_CreateFcn(hObject, eventdata, handles)
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

function sec2upperedit_Callback(hObject, eventdata, handles)
handles.sec2long = str2double(get(hObject,'String'));
guidata(hObject, handles);
function sec2upperedit_CreateFcn(hObject, eventdata, handles)
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

function sec3edit_Callback(hObject, eventdata, handles)
handles.sec3time = str2double(get(hObject,'String'));
handles.stimuliChanges = [handles.stimuliChanges; 
            [GetSecs() handles.circle handles.stimHeight handles.stimWidth...
             handles.orientation handles.maxSatMatch1 handles.maxSatMatch2...
             handles.match1size handles.match2size handles.minSampleSat...
             handles.sec1time handles.sec3time]];
guidata(hObject, handles);
function sec3edit_CreateFcn(hObject, eventdata, handles)
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

function subnumedit_Callback(hObject, eventdata, handles)
handles.subNum = str2double(get(hObject,'String'));
guidata(hObject, handles);
function subnumedit_CreateFcn(hObject, eventdata, handles)
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

% function sesnumedit_Callback(hObject, eventdata, handles)
% handles.sesNum = str2double(get(hObject,'String'));
% guidata(hObject, handles);
% function sesnumedit_CreateFcn(hObject, eventdata, handles)
% if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
%     set(hObject,'BackgroundColor','white');
% end

function match1sizeedit_Callback(hObject, eventdata, handles)
handles.match1size = str2double(get(hObject,'String'));
handles.stimuliChanges = [handles.stimuliChanges; 
            [GetSecs() handles.circle handles.stimHeight handles.stimWidth...
             handles.orientation handles.maxSatMatch1 handles.maxSatMatch2...
             handles.match1size handles.match2size handles.minSampleSat...
             handles.sec1time handles.sec3time]];
guidata(hObject, handles);
function match1sizeedit_CreateFcn(hObject, eventdata, handles)
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

function match2sizeedit_Callback(hObject, eventdata, handles)
handles.match2size = str2double(get(hObject,'String'));
handles.stimuliChanges = [handles.stimuliChanges; 
            [GetSecs() handles.circle handles.stimHeight handles.stimWidth...
             handles.orientation handles.maxSatMatch1 handles.maxSatMatch2...
             handles.match1size handles.match2size handles.minSampleSat...
             handles.sec1time handles.sec3time]];
guidata(hObject, handles);
function match2sizeedit_CreateFcn(hObject, eventdata, handles)
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

function fixsizeedit_Callback(hObject, eventdata, handles)
handles.fixSize = str2double(get(hObject,'String'));
guidata(hObject, handles);
function fixsizeedit_CreateFcn(hObject, eventdata, handles)
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

function fixboxslider_Callback(hObject, eventdata, handles)
handles.fixBoxSize = get(hObject,'Value');
set(handles.fixboxsizeout,'String',handles.fixBoxSize);
guidata(hObject, handles);
function fixboxslider_CreateFcn(hObject, eventdata, handles)
if isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor',[.9 .9 .9]);
end

function uppermatchboxslider_Callback(hObject, eventdata, handles)
handles.upperBoxSize = get(hObject,'Value');
set(handles.uppermatchboxsizeout,'String',handles.upperBoxSize);
guidata(hObject,handles);
function uppermatchboxslider_CreateFcn(hObject, eventdata, handles)
if isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor',[.9 .9 .9]);
end

function lowermatchboxslider_Callback(hObject, eventdata, handles)
handles.lowerBoxSize = get(hObject,'Value');
set(handles.lowermatchboxsizeout,'String',handles.lowerBoxSize);
guidata(hObject,handles);
function lowermatchboxslider_CreateFcn(hObject, eventdata, handles)
if isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor',[.9 .9 .9]);
end

function sampleboxslider_Callback(hObject, eventdata, handles)
handles.sampleBoxSize = get(hObject,'Value');
set(handles.sampleboxsizeout,'String',handles.sampleBoxSize);
guidata(hObject,handles);
function sampleboxslider_CreateFcn(hObject, eventdata, handles)
if isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor',[.9 .9 .9]);
end

function samplesidepopup_Callback(hObject, eventdata, handles)
contents = get(hObject,'String');
handles.sampleSide = contents{get(hObject,'Value')};
if strcmp(handles.sampleSide,'Left')
  handles.sampleLocx = handles.width - (handles.sampleLocx-handles.width);
end
if strcmp(handles.sampleSide,'Left')
   handles.match1Locx = (handles.width-handles.match1Locx) + handles.width;
   handles.match2Locx = (handles.width-handles.match2Locx) + handles.width;
   handles.match3Locx = (handles.width-handles.match3Locx) + handles.width;
end
% if strcmp(handles.sampleSide,'Left')
%    handles.match1Locx = handles.match1Locx + handles.width;
%    handles.match2Locx = handles.match2Locx + handles.width;
%    handles.match3Locx = handles.match3Locx + handles.width;
% end
handles = plotBoxes2(handles);
guidata(hObject,handles);
function samplesidepopup_CreateFcn(hObject, eventdata, handles)
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

function maxsatmatch2popup_Callback(hObject, eventdata, handles)
contents = get(hObject,'String');
handles.maxSatMatch2 = str2double(contents{get(hObject,'Value')});
handles.stimuliChanges = [handles.stimuliChanges; 
            [GetSecs() handles.circle handles.stimHeight handles.stimWidth...
             handles.orientation handles.maxSatMatch1 handles.maxSatMatch2...
             handles.match1size handles.match2size handles.minSampleSat...
             handles.sec1time handles.sec3time]];
guidata(hObject,handles);
function maxsatmatch2popup_CreateFcn(hObject, eventdata, handles)
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

function maxsatmatch1popup_Callback(hObject, eventdata, handles)
contents = get(hObject,'String');
handles.maxSatMatch1 = str2double(contents{get(hObject,'Value')});
handles.stimuliChanges = [handles.stimuliChanges; 
            [GetSecs() handles.circle handles.stimHeight handles.stimWidth...
             handles.orientation handles.maxSatMatch1 handles.maxSatMatch2...
             handles.match1size handles.match2size handles.minSampleSat...
             handles.sec1time handles.sec3time]];
guidata(hObject,handles);
function maxsatmatch1popup_CreateFcn(hObject, eventdata, handles)
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

function minsamplesatpopup_Callback(hObject, eventdata, handles)
contents = get(hObject,'String');
handles.minSampleSat = str2double(contents{get(hObject,'Value')});
handles.stimuliChanges = [handles.stimuliChanges; 
            [GetSecs() handles.circle handles.stimHeight handles.stimWidth...
             handles.orientation handles.maxSatMatch1 handles.maxSatMatch2...
             handles.match1size handles.match2size handles.minSampleSat...
             handles.sec1time handles.sec3time]];
guidata(hObject,handles);
function minsamplesatpopup_CreateFcn(hObject, eventdata, handles)
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

function fixlocsliderx_Callback(hObject, eventdata, handles)
handles.fixLocx = get(hObject,'Value');
set(handles.fixlocxout,'String',handles.fixLocx);
guidata(hObject, handles);
function fixlocsliderx_CreateFcn(hObject, eventdata, handles)
if isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor',[.9 .9 .9]);
end

function fixlocslidery_Callback(hObject, eventdata, handles)
handles.fixLocy = get(hObject,'Value');
set(handles.fixlocyout,'String',handles.fixLocy);
guidata(hObject, handles);
function fixlocslidery_CreateFcn(hObject, eventdata, handles)
if isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor',[.9 .9 .9]);
end

function samplelocsliderx_Callback(hObject, eventdata, handles)
handles.sampleLocx = get(hObject,'Value');
set(handles.samplelocxout,'String',handles.sampleLocx);
if strcmp(handles.sampleSide,'Left')
   handles.sampleLocx = handles.sampleLocx - handles.width; 
end
guidata(hObject, handles);
function samplelocsliderx_CreateFcn(hObject, eventdata, handles)
if isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor',[.9 .9 .9]);
end

function samplelocslidery_Callback(hObject, eventdata, handles)
handles.sampleLocy = get(hObject,'Value');
set(handles.samplelocyout,'String',handles.sampleLocy);
guidata(hObject, handles);
function samplelocslidery_CreateFcn(hObject, eventdata, handles)
if isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor',[.9 .9 .9]);
end

function match1sliderx_Callback(hObject, eventdata, handles)
handles.xDisplacement = get(hObject,'Value');
handles.match1Locx = handles.width-handles.xDisplacement*cosd(handles.matchAngle);
handles.match1Locy = handles.height-handles.xDisplacement*sind(handles.matchAngle);
handles.match2Locx = handles.width - handles.xDisplacement;
handles.match2Locy = handles.height;
handles.match3Locx = handles.width-handles.xDisplacement*cosd(handles.matchAngle);
handles.match3Locy = handles.height+handles.xDisplacement*sind(handles.matchAngle);
if strcmp(handles.sampleSide,'Left')
   handles.match1Locx = (handles.width-handles.match1Locx) + handles.width;
   handles.match2Locx = (handles.width-handles.match2Locx) + handles.width;
   handles.match3Locx = (handles.width-handles.match3Locx) + handles.width;
end
% if strcmp(handles.sampleSide,'Left')
%    handles.match1Locx = handles.match1Locx + handles.width;
%    handles.match2Locx = handles.match2Locx + handles.width;
%    handles.match3Locx = handles.match3Locx + handles.width;
% end
% handles = plotBoxes2(handles);
set(handles.correctmatchxout,'String',handles.match2Locx);
guidata(hObject, handles);
function match1sliderx_CreateFcn(hObject, eventdata, handles)
if isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor',[.9 .9 .9]);
end

function match1slidery_Callback(hObject, eventdata, handles)
%handles.match1Locy = get(hObject,'Value');
%set(handles.uppermatchyout,'String',handles.match1Locy);
handles.matchAngle = get(hObject,'Value');
handles.match1Locx = handles.width-handles.xDisplacement*cosd(handles.matchAngle);
handles.match1Locy = handles.height-handles.xDisplacement*sind(handles.matchAngle);
handles.match3Locx = handles.width-handles.xDisplacement*cosd(handles.matchAngle);
handles.match3Locy = handles.height+handles.xDisplacement*sind(handles.matchAngle);
if strcmp(handles.sampleSide,'Left')
   handles.match1Locx = (handles.width-handles.match1Locx) + handles.width;
   handles.match3Locx = (handles.width-handles.match3Locx) + handles.width;
end
set(handles.uppermatchyout,'String',handles.matchAngle);
guidata(hObject, handles);
% handles.matchAngle = get(hObject,'Value');
% handles.match1Locx = handles.width-handles.xDisplacement*cosd(handles.matchAngle);
% handles.match1Locy = handles.height-handles.xDisplacement*sind(handles.matchAngle);
% handles.match3Locx = handles.width-handles.xDisplacement*cosd(handles.matchAngle);
% handles.match3Locy = handles.height+handles.xDisplacement*sind(handles.matchAngle);
% set(handles.uppermatchyout,'String',handles.matchAngle);
% guidata(hObject, handles);
function match1slidery_CreateFcn(hObject, eventdata, handles)
if isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor',[.9 .9 .9]);
end

function match2slidery_Callback(hObject, eventdata, handles)
if strcmp(handles.sampleSide,'Left')
   handles.match1Locx = handles.match1Locx + handles.width;
   handles.match3Locx = handles.match3Locx + handles.width;
end
%handles.match2Locy = get(hObject,'Value');
%set(handles.middlematchyout,'String',handles.match2Locy);
%guidata(hObject, handles);
function match2slidery_CreateFcn(hObject, eventdata, handles)
if isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor',[.9 .9 .9]);
end

function match3slidery_Callback(hObject, eventdata, handles)
%handles.match3Locy = get(hObject,'Value');
%set(handles.lowermatchyout,'String',handles.match3Locy);
%guidata(hObject, handles);
function match3slidery_CreateFcn(hObject, eventdata, handles)
if isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor',[.9 .9 .9]);
end

function fixcoloredit_Callback(hObject, eventdata, handles)
handles.fixColor = str2double(get(hObject,'String'));
guidata(hObject, handles);
function fixcoloredit_CreateFcn(hObject, eventdata, handles)
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

function sampleDelayEdit_Callback(hObject, eventdata, handles)
handles.sampleDelay = str2double(get(hObject,'String'));
guidata(hObject, handles);
function sampleDelayEdit_CreateFcn(hObject, eventdata, handles)
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

function matchDelayEdit_Callback(hObject, eventdata, handles)
handles.matchDelay = str2double(get(hObject,'String'));
guidata(hObject, handles);
function matchDelayEdit_CreateFcn(hObject, eventdata, handles)
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

% --- Executes on button press in runbutton.
% --- Runs cycle
function runbutton_Callback(hObject, eventdata, handles)
%-construct text files----------------------------------------------------%
handles = createPath(handles);
handles.filenameEye = ['cycle' num2str(handles.cycleNum) 'EyeData'];
handles.filenameResults = ['cycle' num2str(handles.cycleNum) 'Results'];
handles.filenameStimuli = ['cycle' num2str(handles.cycleNum) 'Stimuli'];
handles = createTextFiles(handles);
handles.writeFrequency = 5;
guidata(hObject,handles);
%-------------------------------------------------------------------------%
%-begin program-----------------------------------------------------------%
while(handles.finish)
    handles.allOK = 1;
    handles = updateHandles(handles,'new trial',' ',' ');
    guidata(hObject, handles)
    handles = plotBoxes2(handles);
    if handles.trialsToComplete(handles.count)
        handles = runTrial(hObject, handles);
    else
        handles.count = handles.count + 1;
        if (handles.count > handles.trialTotal && sum(handles.trialsToComplete) == 0)
            handles.finish = 0;
        elseif (handles.count > handles.trialTotal)
            handles.count = 1;
        end
    end
    if handles.finish == 0, f = 'finish'; else f = ' '; end
    handles = updateHandles(handles,' ',' ',f);
    guidata(hObject, handles)
end
copyfile('C:\Documents and Settings\admin\Desktop\colorProgVer3b\colorProgVer3GUI.m',...
         [handles.directory '\colorProgVer3GUI.m']);
copyfile('C:\Documents and Settings\admin\Desktop\colorProgVer3b\colorProgVer3GUI.fig',...
         [handles.directory '\colorProgVer3GUI.fig']);
handles = writeData(handles);   
handles = updateHandles(handles,' ','erase',' ');
guidata(hObject, handles)

function handles = runTrial(hObject,handles)
disp('run trial');
set(handles.showCount,'String',num2str(handles.count),'FontSize',12);
%---section 1--fixation only--------------------------------------%
handles = displayFixPoint(handles);
Screen(handles.wPtr,'Flip');
%WaitSecs(.5);
WaitSecs(.25);
currentTime = GetSecs;
i=0;
while(GetSecs-currentTime < handles.sec1time)% && handles.allOK)
    disp('sec 1');
    handles = currentEyePos(handles);
    handles.eyePos(handles.eyeCount,:) = [GetSecs() handles.eyex handles.eyey];
    if (rem(i,5)==0)
        handles = displayEyePos(handles);
    end
    handles = checkEyePosition(handles);
    handles.eyeCount = handles.eyeCount + 1;
    if ~handles.eyeIsFixed
        currentTime = GetSecs;
        handles = updateHandles(handles,' ',' ',' ');
    else
        handles = updateHandles(handles,'new trial',' ',' ');
    end
    %-------------------------------------------------------------%
    [keyIsDown, secs, keyCode] = KbCheck;
    %--givejuice
    if keyCode(74)   %"j"
        handles = giveJuice(handles);
    end
    %-------------------------------------------------------------%
end
disp(['handles.allOK = ' num2str(handles.allOK)]);
% handles = updateHandles(handles,' ',' ',' ');
guidata(hObject, handles);
%-----------------------------------------------------------------%
disp(['handles.allOK = ' num2str(handles.allOK)]);
%---section 2--fixation, sampleboxslider-----------------------------------%
currentTime = GetSecs;
handles.sec2time = rand(1)*(handles.sec2long-handles.sec2short)+handles.sec2short;
if (handles.eyeIsFixed && handles.allOK)
    disp('sec 2');
    handles = displayFixPoint(handles);
    handles = displaySample(handles);
    %handles = giveJuice(handles);  %ROSA added 11/24/09 for Pollux to reduce looking at sample
    Screen(handles.wPtr,'Flip');
    while(GetSecs-currentTime < handles.sec2time && handles.allOK)
        handles = currentEyePos(handles);
        handles.eyePos(handles.eyeCount,:) = [GetSecs() handles.eyex handles.eyey];
        handles = displayEyePos(handles);
        handles = checkEyePosition(handles);
        handles.eyeCount = handles.eyeCount + 1;
        %---------------------------------------------------------%
        [keyIsDown, secs, keyCode] = KbCheck;
        %--givejuice
        if keyCode(74)   %"j"
            handles = giveJuice(handles);
        end
        %---------------------------------------------------------%
    end
    handles = updateHandles(handles,' ',' ',' ');
    guidata(hObject, handles);
end
%-----------------------------------------------------------------%

%---section 3--matches only---------------------------------------%
if (handles.eyeIsFixed && handles.allOK)
    handles = displayMatches(handles);
    %disp(['matchMX: ' num2str(handles.matchMX)]);
    Screen(handles.wPtr,'Flip');
    handles.responses (handles.count,1:5) = [handles.count ...
        handles.stimMX(4,handles.count) ...
        handles.stimMX(5,handles.count)...
        handles.stimMX(6,handles.count)...
        GetSecs()];
    handles.responses(handles.count,6:9) = ...
        [9999 GetSecs() 9999 handles.sec2time];  %default
    currentTime = GetSecs;
    while(GetSecs-currentTime < handles.sec3time && handles.allOK)
        disp('sec 3');
        handles = currentEyePos(handles);
        handles.eyePos(handles.eyeCount,:) = [GetSecs() handles.eyex handles.eyey];
        handles = displayEyePos(handles);
        handles = checkEyePosition(handles);
        handles.eyeCount = handles.eyeCount + 1;
        % if gaze leaves fixation box
        if ~handles.eyeIsFixed
            %WaitSecs(.005);  % small pause
            disp('not fixed...');
            handles = currentEyePos(handles);
            handles.eyePos(handles.eyeCount,:) = [GetSecs() handles.eyex handles.eyey];
            handles = displayEyePos(handles);
            handles.eyeCount = handles.eyeCount + 1;
            handles.eyeChoice = 0;
%             disp(['x eye: ' num2str(handles.eyex)]);
%             disp(['y eye: ' num2str(handles.eyex)]);
%             disp(['m1RB: ' num2str(handles.match1RightBound)]);
%             disp(['m1LB: ' num2str(handles.match1LeftBound)]);
%             disp(['m1UB: ' num2str(handles.match1UpperBound)]);
%             disp(['m1LoB: ' num2str(handles.match1LowerBound)]);
%             disp(['m2RB: ' num2str(handles.match2RightBound)]);
%             disp(['m2LB: ' num2str(handles.match2LeftBound)]);
%             disp(['m2UB: ' num2str(handles.match2UpperBound)]);
%             disp(['m2LoB: ' num2str(handles.match2LowerBound)]);
%             disp(['m3RB: ' num2str(handles.match3RightBound)]);
%             disp(['m3LB: ' num2str(handles.match3LeftBound)]);
%             disp(['m3UB: ' num2str(handles.match3UpperBound)]);
%             disp(['m3LoB: ' num2str(handles.match3LowerBound)]);
%             disp(['matchMX: ' num2str(handles.matchMX)]);
            % if gaze falls within match boxes
            if (handles.eyex < handles.match1RightBound) && ...
                    (handles.eyex > handles.match1LeftBound) && ...
                    (handles.eyey < handles.match1LowerBound) && ...
                    (handles.eyey > handles.match1UpperBound)
                    %handles.eyeChoice = handles.matchOne;
                    handles.eyeChoice = handles.matchMX(1);
                    handles.responses(handles.count,6:7) = ...
                        [handles.eyeChoice GetSecs()];
            elseif (handles.eyex < handles.match2RightBound) && ...
                    (handles.eyex > handles.match2LeftBound) && ...
                    (handles.eyey < handles.match2LowerBound) && ...
                    (handles.eyey > handles.match2UpperBound)
                 %disp('middle box');
                    %handles.eyeChoice = handles.matchTwo;
                    handles.eyeChoice = handles.matchMX(2);
                    handles.responses(handles.count,6:7) = ...
                        [handles.eyeChoice GetSecs()];
            elseif (handles.eyex < handles.match3RightBound) && ...
                    (handles.eyex > handles.match3LeftBound) && ...
                    (handles.eyey < handles.match3LowerBound) && ...
                    (handles.eyey > handles.match3UpperBound)
                    %handles.eyeChoice = handles.matchTwo;
                    handles.eyeChoice = handles.matchMX(3);
                    handles.responses(handles.count,6:7) = ...
                        [handles.eyeChoice GetSecs()];
            end
          %disp(['choice = ' num2str(handles.eyeChoice)]);
          % if a choice was made
          if handles.eyeChoice
              handles = displayCorrectMatch(handles);
              Screen(handles.wPtr,'Flip');
              WaitSecs(.25);
              if handles.eyeChoice == handles.stimMX(4,handles.count)
                  handles = giveJuice(handles);
                  handles.responses(handles.count,8) = 1;
              else
                  handles.responses(handles.count,8) = 0;
                  disp('incorrect match selected: penalty')
                  Screen(handles.wPtr,'Flip');
                  currentTime = GetSecs;
                  while(GetSecs-currentTime < handles.matchDelay)% && handles.allOK)   PENALTY  (looking at wrong match)
                      handles = currentEyePos(handles);
                      handles.eyePos(handles.eyeCount,:) = [GetSecs() handles.eyex handles.eyey];
                      handles = displayEyePos(handles);
                      handles.eyeCount = handles.eyeCount + 1;
                      [keyIsDown, secs, keyCode] = KbCheck;
                      %--givejuice
                      if keyCode(74)   %"j"
                          handles = giveJuice(handles);
                      end
                      %---------------------------------------------------%
                  end
                  handles = updateHandles(handles,' ',' ',' ');
                  guidata(hObject, handles);
              end
              handles.trialsToComplete(handles.count) = 0; % trial is complete,
              % don't return again
          end
          currentTime = -100;   % break while loop
        else     % eye.isFixed
            handles.responses(handles.count,6:9) = [9999 GetSecs() 9999 handles.sec2time];
            % update default
        end
        %---------------------------------------------------------%
        [keyIsDown, secs, keyCode] = KbCheck;
        %--givejuice
        if keyCode(74)   %"j"
            handles = giveJuice(handles);
        end
        %---------------------------------------------------------%
    end
    handles = updateHandles(handles,' ',' ',' ');
    guidata(hObject, handles);
end
handles.count = handles.count + 1;
if (handles.count > handles.trialTotal && sum(handles.trialsToComplete) == 0)
    handles.finish = 0;
elseif (handles.count > handles.trialTotal)
    handles.count = 1;
end
%end

if(rem(handles.count-1,handles.writeFrequency)==0)
    handles = writeData(handles);
    handles = updateHandles(handles,' ','erase',' ');
    guidata(hObject, handles)
end

function handles = displayFixPoint(handles)
s = handles.fixSize;
c = handles.fixColor;
x = handles.fixLocx;
y = handles.fixLocy;
Screen('FillOval',handles.wPtr,[c c c],[x-s, y-s, x+s, y+s]);
set(handles.matchCorrect,'XData',0,'YData',0);
set(handles.matchIncorrect,'XData',0,'YData',0);
drawnow;

function handles = currentEyePos(handles)
ai = handles.ai;
height = handles.height;
data = peekdata(ai,1);
x = (((data(1) + 3.5)*200*3/4)+142.5)*.954;
handles.eyex = x * 3/4;
y = (((data(2) + 4.5)*130*3/4)+12.85)*1.00;
handles.eyey = 3/4*(2*height-y);

function handles = displayEyePos(handles)
set(handles.eyeStore,'XData',handles.eyePos(:,2),...
    'YData',handles.eyePos(:,3));
set(handles.eyeCurrent,'XData',handles.eyex,'YData',handles.eyey);
drawnow;

function handles = displaySample(handles)
wPtr = handles.wPtr;
count = handles.count;
mx = handles.stimMX;
% disp(['sample number' num2str(mx(4,count))]);
% disp(['sample color: ' num2str(mx(1,count))]);
% disp(['sample color: ' num2str(mx(2,count))]);
% disp(['sample color: ' num2str(mx(3,count))]);
locx = handles.sampleLocx;
% if strcmp(handles.sampleSide,'Left')
%     locx = handles.sampleLocx - handles.width;
% end
locy = handles.sampleLocy;
height = handles.stimHeight;
orientation = handles.orientation;
width = handles.stimWidth;
if handles.bar
    Screen('DrawLine', wPtr, mx(1:3,count).*255,...
        locx - .5*(height*cosd(orientation)),...
        locy + .5*(height*sind(orientation)),...
        locx + .5*(height*cosd(orientation)),...
        locy - .5*(height*sind(orientation)),...
        width);
elseif handles.circle
    Screen('FillOval',wPtr,mx(1:3,count),[locx-height/2,locy-height/2,...
        locx+height/2,locy+height/2]);
end
set(handles.sampleSymbol,'XData',locx*3/4,...
    'YData',3/4*(2*handles.height-locy));
drawnow;

function handles = displayMatches(handles)
% disp(num2str(handles.match1Locx));
% disp(num2str(handles.match1Locy));
% disp(num2str(handles.matchAngle));
count = handles.count;
mx = handles.stimMX;
wPtr = handles.wPtr;
%loc1 = handles.match1Locx;
%loc2 = handles.match2Locx;
%loc3 = handles.match3Locx;
if strcmp(handles.sampleSide,'Left')
    loc1x = handles.match1Locx + handles.width;
    loc2x = handles.match2Locx + handles.width;
end
%loc1y = handles.match1Locy; loc2y = handles.match2Locy;
%disp(['match1loc' num2str(handles.matchlocs(count))]);
%disp(['match2loc' num2str(handles.matchlocs(count))]);
if handles.matchlocs(count) == 1
    loc1y = handles.match1Locy; loc1x = handles.match1Locx;
elseif handles.matchlocs(count) == 2
    loc1y = handles.match2Locy; loc1x = handles.match2Locx;
elseif handles.matchlocs(count) == 3
    loc1y = handles.match3Locy; loc1x = handles.match3Locx;
end
if handles.incorMatchLocs(count) == 1
    loc2y = handles.match1Locy; loc2x = handles.match1Locx;
elseif handles.incorMatchLocs(count) == 2
    loc2y = handles.match2Locy; loc2x = handles.match2Locx;
elseif handles.incorMatchLocs(count) == 3
    loc2y = handles.match3Locy; loc2x = handles.match3Locx;
end
% if strcmp(handles.sampleSide,'Left')
%     loc1x = loc1x + handles.width;
%     loc2x = loc2x + handles.width;
% end
%disp(['loc1 ' num2str(loc1y)]);
%disp(['loc2 ' num2str(loc2y)]);
%disp(['match = ' num2str(mx(4,count))]);

correct = handles.matchCorrect;
incorrect = handles.matchIncorrect;
screenHeight = handles.height;
[rCor gCor bCor] = colorFind(mx(4,count),handles.maxSatMatch1);        % match1
[rIncor gIncor bIncor] = colorFind(mx(6,count),handles.maxSatMatch2);  % match2
handles.matchMX = zeros(1,3);
handles.matchMX(handles.matchlocs(count)) = mx(4,count);
handles.matchMX(handles.incorMatchLocs(count)) = mx(6,count);
%if handles.matchupdown(count) == 0
%handles.matchOne = mx(4,count);
Screen('FillOval',wPtr,[rCor gCor bCor],...
    [loc1x-handles.match1size/2,...
    loc1y-handles.match1size/2,...
    loc1x+handles.match1size/2,...
         loc1y+handles.match1size/2]);
    set(correct,'XData',loc1x*3/4,...
                      'YData',3/4*(2*screenHeight-loc1y));
    handles.matchTwo = mx(6,count);
    Screen('FillOval',wPtr,[rIncor gIncor bIncor],...
        [loc2x-handles.match2size/2,...
         loc2y-handles.match2size/2,...
         loc2x+handles.match2size/2,...
         loc2y+handles.match2size/2]);
    set(incorrect,'XData',loc2x*3/4,...
                  'YData',3/4*(2*screenHeight-loc2y));  
set(handles.sampleSymbol,'XData',0,'YData',0);
drawnow;

function handles = displayCorrectMatch(handles)
count = handles.count;
mx = handles.stimMX;
wPtr = handles.wPtr;
if strcmp(handles.sampleSide,'Left')
    loc1x = handles.match1Locx + handles.width;
end
if handles.matchlocs(count) == 1
    loc1y = handles.match1Locy; loc1x = handles.match1Locx;
elseif handles.matchlocs(count) == 2
    loc1y = handles.match2Locy; loc1x = handles.match2Locx;
elseif handles.matchlocs(count) == 3
    loc1y = handles.match3Locy; loc1x = handles.match3Locx;
end
[rCor gCor bCor] = colorFind(mx(4,count),handles.maxSatMatch1);        % match1
Screen('FillOval',wPtr,[rCor gCor bCor],...
        [loc1x-handles.match1size/2,...
         loc1y-handles.match1size/2,...
         loc1x+handles.match1size/2,...
         loc1y+handles.match1size/2]);
     
function handles = checkEyePosition(handles)
x = handles.eyex; y = handles.eyey;
LBound = handles.fixLeftBound; RBound = handles.fixRightBound;
UBound = handles.fixUpperBound; LwBound = handles.fixLowerBound;
sampX = handles.sampleLocx; sampY = handles.sampleLocy;
handles.eyeIsFixed = 1;
if (x<LBound) || (x>RBound) || (y<UBound) || (y>LwBound) % looking outside of fixation...
    handles.eyeIsFixed = 0;
    handles.allOK = 0;
    disp(num2str(handles.count));
    
    if (x<handles.sampleRightBound) && (x>handles.sampleLeftBound) &&...
       (y<handles.sampleLowerBound) && (y>handles.sampleUpperBound) % looking at sample...
        disp('movement to sample: penalty');     
        Screen(handles.wPtr,'Flip');
        currentTime = GetSecs;
        while(GetSecs-currentTime < handles.sampleDelay)% && handles.allOK)   PENALTY (movement to sample)
            handles = currentEyePos(handles);
            handles.eyePos(handles.eyeCount,:) = [GetSecs() handles.eyex handles.eyey];
            handles = displayEyePos(handles);
            handles.eyeCount = handles.eyeCount + 1;
            [keyIsDown, secs, keyCode] = KbCheck;
            %--givejuice
            if keyCode(74)   %"j"
                handles = giveJuice(handles);
            end
            %-------------------------------------------------------------%
        end
        handles = updateHandles(handles,' ',' ',' ');
%         guidata(hObject, handles);
        WaitSecs(1);   %CHANGE PENALTY DURATION HERE
    end
end
handles = updateHandles(handles,' ',' ',' ');
% guidata(hObject, handles);

function handles = giveJuice(handles)
%sends output to juicer
for i=1:handles.numDrops
    %----setting all lines of digital output to 1 and then back to 0----%
    iodata = linspace(1,1,handles.outlines+1);
    putvalue(handles.dio,iodata);
    iodata = linspace(0,0,handles.outlines+1);
    putvalue(handles.dio,iodata);
end

function handles = writeData(handles) 
resultsName = handles.filenameResults;
eyeName = handles.filenameEye;
responses = handles.responses;
pos = handles.eyePos;
mxSize = size(handles.stimMX,2);  
fid = fopen(resultsName, 'a');
i = find(responses(:,1),1);
while (i <= length(responses(:,1)))
    if (responses(i,1)~=0) 
        fprintf(fid, '%-12.0d %-12d %-12d %-15d %-6.5d  %-14.0d %-6.5d  %-9.0f %-9.2f\n',... 
                 responses(i,1),...
                 responses(i,2),...
                 responses(i,3),...
                 responses(i,4),...
                 responses(i,5),...
                 responses(i,6),...
                 responses(i,7),...
                 responses(i,8),...
                 responses(i,9));
    end
    i = i + 1;
end
fclose(fid);
fid = fopen(eyeName, 'a');
i = find(pos(:,1),1);
while (pos(i,1)~=0) 
    fprintf(fid, '%-6.5d %-11.3d %-11.3d\n',... 
                 pos(i,1),...
                 pos(i,2),...
                 pos(i,3));   
    i = i+1;     
end
fclose(fid);
fid = fopen(handles.filenameStimuli,'a');
sc = handles.stimuliChanges;
for i=1:size(handles.stimuliChanges,1)
    fprintf(fid,'%-4.3f %-8.0f %-7.0f %-7.0f %-7.0f %-10.0f %-12.0f %-13.0f %-15.0f %-11.0f %-9.3f %-9.3f %-9.3f\n',...
            sc(i,1),sc(i,2),sc(i,3),sc(i,4),sc(i,5),sc(i,6),sc(i,7),sc(i,8),...
            sc(i,9),sc(i,10),sc(i,11),sc(i,12));
end
fclose(fid);
handles.eyePos = zeros(80000,3);
handles.responses = zeros(mxSize,8); 

function handles = createTextFiles(handles)          
fid = fopen(handles.filenameResults,'w');
fprintf(fid,'%s %3d\n\n','Subject number',handles.subNum);
fprintf(fid,'%s %3d\n','Session number',handles.sesNum);
fprintf(fid,'%s %3d\n\n','Cycle number',handles.cycleNum);
fprintf(fid,'%s\n',date);
c = clock;
fprintf(fid,'%2.0f:%2.0f:%2.0f\n\n',c(4),c(5),c(6));
fprintf(fid,'%s %5d\n\n','Number of trials',handles.trialTotal);
fprintf(fid,'%s\n\n','Modified 8AFC. Designed Dec''08/Jan''09');
fprintf(fid,'%s\n\n','Stimuli composition and responses:');
if handles.bar
    fprintf(fid,'%-15s %-4.1f   %-7s %-4.1f   %-13s %-4.1f\n',...
                'Sample height:',sample.stimHeight,...
                'width:',sample.stimWidth,...
                'orientation:',sample.orientation);
elseif handles.circle
    fprintf(fid,'%-20s   %-5s %-4.0f\n',...
            'Sample shape: circle', 'Size:', handles.stimHeight); 
end
fprintf(fid,'%s%-4.1f%s%-4.1f%s\n\n',...
            'Sample center point: [', handles.sampleLocx,...  %change to monkey
            ',', handles.sampleLocy, ']');
fprintf(fid,'%-12s %-10s %-12s %-11s %-7s %-7s %-13s %-12s %-14s\n\n', 'Trial count',...
                                                      'Red value','Green value',...
                                                      'Blue value', 'Number',...
                                                      'Amount','Compared to',...
                                                      'CorMatchLoc','IncorMatchLoc');
record = handles.stimuliRecord;
for j = 1 : size(record,2)  
fprintf(fid, '%-12.0f %-10.5f %-12.5f %-11.5f %-7.0f %-7.0f %-13.0f %-12.0f %-14.0f\n',...
            record(1,j), record(2,j),...
            record(3,j), record(4,j),...
            record(5,j), record(6,j),...
            record(7,j), record(8,j),...
            record(9,j));      
end
fprintf(fid,'\n%-12s %-12s %-12s %-15s %-13s %-14s %-13s %-9s %-9s\n\n','Trial count',...
            'Hue Number','Sat. Amount','Compare Number','Time (start)',...
            'Response made','Time (resp.)','Correct?','Sec2Time');
fclose(fid);
fid = fopen(handles.filenameEye,'w');
fprintf(fid,'%s %3d\n\n','Subject number',handles.subNum);
fprintf(fid,'%s %3d\n','Session number',handles.sesNum);
fprintf(fid,'%s %3d\n\n','Cycle number',handles.cycleNum);
fprintf(fid,'%s\n',date);
c = clock;
fprintf(fid,'%2.0f:%2.0f:%2.0f\n\n',c(4),c(5),c(6));
fprintf(fid,'%s %5d\n\n','Number of trials',handles.trialTotal);
fprintf(fid,'%s\n\n','Modified 8AFC. Designed Dec''08/Jan''09');
fprintf(fid,'%s\n\n','Eye Data:');
fprintf(fid,'%-12s %-11s %-11s\n','Time','X Position','Y Position');  
fid = fopen(handles.filenameStimuli,'w');
fprintf(fid,'%s %3d\n\n','Subject number',handles.subNum);
fprintf(fid,'%s %3d\n','Session number',handles.sesNum);
fprintf(fid,'%s %3d\n\n','Cycle number',handles.cycleNum);
fprintf(fid,'%s\n',date);
c = clock;
fprintf(fid,'%2.0f:%2.0f:%2.0f\n\n',c(4),c(5),c(6));
fprintf(fid,'%s %5d\n\n','Number of trials',handles.trialTotal);
fprintf(fid,'%s\n\n','Stimuli:');
fprintf(fid,'%-8s %-8s %-7s %-7s %-7s %-10s %-12s %-13s %-15s %-11s %-9s %-9s\n',...
            'Time','Circle?','Height','Width','Orient.','MaxSatCor','MaxSatIncor',...
            'CorMatchSize','IncorMatchSize','MinSampSat','Sec1Time','Sec3Time') 
fclose(fid);

function handles = plotBoxes1(handles)
handles.match1LeftBound = (3/4)*(handles.match1Locx) - handles.upperBoxSize/2;
handles.match1RightBound = (3/4)*(handles.match1Locx) + handles.upperBoxSize/2;
handles.match2LeftBound = (3/4)*(handles.match2Locx) - handles.upperBoxSize/2;
handles.match2RightBound = (3/4)*(handles.match2Locx) + handles.upperBoxSize/2;
handles.match3LeftBound = (3/4)*(handles.match3Locx) - handles.upperBoxSize/2;
handles.match3RightBound = (3/4)*(handles.match3Locx) + handles.upperBoxSize/2;
handles.match1UpperBound = 3/4*(2*handles.height-handles.match1Locy) - handles.upperBoxSize/2;
handles.match1LowerBound = 3/4*(2*handles.height-handles.match1Locy) + handles.upperBoxSize/2;
handles.match2UpperBound = 3/4*(2*handles.height-handles.match2Locy) - handles.upperBoxSize/2;
handles.match2LowerBound = 3/4*(2*handles.height-handles.match2Locy) + handles.upperBoxSize/2;
handles.match3UpperBound = 3/4*(2*handles.height-handles.match3Locy) - handles.upperBoxSize/2;
handles.match3LowerBound = 3/4*(2*handles.height-handles.match3Locy) + handles.upperBoxSize/2;
handles.sampleLeftBound = (3/4)*(handles.sampleLocx) - handles.sampleBoxSize/2;
handles.sampleRightBound = (3/4)*(handles.sampleLocx) + handles.sampleBoxSize/2;
handles.sampleUpperBound = 3/4*(2*handles.height-handles.sampleLocy) - handles.sampleBoxSize/2;
handles.sampleLowerBound = 3/4*(2*handles.height-handles.sampleLocy) + handles.sampleBoxSize/2;
handles.fixLeftBound = (3/4)*(handles.fixLocx) - handles.fixBoxSize/2;
handles.fixRightBound = (3/4)*(handles.fixLocx) + handles.fixBoxSize/2;
handles.fixUpperBound = 3/4*(2*handles.height-handles.fixLocy) - handles.fixBoxSize/2;
handles.fixLowerBound = 3/4*(2*handles.height-handles.fixLocy) + handles.fixBoxSize/2;
fLB = handles.fixLeftBound; 
fRB = handles.fixRightBound;
fLoB = handles.fixLowerBound; fUB = handles.fixUpperBound;
m1LB = handles.match1LeftBound; m1RB = handles.match1RightBound;
m2LB = handles.match2LeftBound; m2RB = handles.match2RightBound;
m3LB = handles.match3LeftBound; m3RB = handles.match3RightBound;
m1LoB = handles.match1LowerBound; m2LoB = handles.match2LowerBound;
m1UB = handles.match1UpperBound; m2UB = handles.match2UpperBound;
m3LoB = handles.match3LowerBound; m3UB = handles.match3UpperBound; %
sLB = handles.sampleLeftBound; sRB = handles.sampleRightBound;
sLoB = handles.sampleLowerBound; sUB = handles.sampleUpperBound;
fixX = [fLB fLB fRB fRB fLB];
fixY = [fLoB fUB fUB fLoB fLoB];
x1Data = [m1LB m1LB m1RB m1RB m1LB];
x2Data = [m2LB m2LB m2RB m2RB m2LB];
x3Data = [m3LB m3LB m3RB m3RB m3LB];
y1Data = [m1LoB m1UB m1UB m1LoB m1LoB];
y2Data = [m2LoB m2UB m2UB m2LoB m2LoB];
y3Data = [m3LoB m3UB m3UB m3LoB m3LoB]; %
sX = [sLB sLB sRB sRB sLB];
sY = [sLoB sUB sUB sLoB sLoB];
%for i = 1:5
 %   y1Data(i) = y1Data(i);
 %   y2Data(i) = y2Data(i);
 %   y3Data(i) = y3Data(i); %
 %   fixY(i) = fixY(i);
%end
handles.matchBox1 = plot(x1Data,y1Data,':k');
handles.matchBox2 = plot(x2Data,y2Data,':k');
handles.matchBox3 = plot(x3Data,y3Data,':k'); %
handles.fixBox = plot(fixX,fixY,':k');
handles.sampleBox = plot(sX,sY,':k');

function handles = plotBoxes2(handles)
%disp('plotBoxes2...');
handles.match1LeftBound = (3/4)*(handles.match1Locx) - handles.upperBoxSize/2;
handles.match1RightBound = (3/4)*(handles.match1Locx) + handles.upperBoxSize/2;
handles.match2LeftBound = (3/4)*(handles.match2Locx) - handles.upperBoxSize/2;
handles.match2RightBound = (3/4)*(handles.match2Locx) + handles.upperBoxSize/2;
handles.match3LeftBound = (3/4)*(handles.match3Locx) - handles.upperBoxSize/2;
handles.match3RightBound = (3/4)*(handles.match3Locx) + handles.upperBoxSize/2;
handles.match1UpperBound = 3/4*(2*handles.height-handles.match1Locy) - handles.upperBoxSize/2;
handles.match1LowerBound = 3/4*(2*handles.height-handles.match1Locy) + handles.upperBoxSize/2;
handles.match2UpperBound = 3/4*(2*handles.height-handles.match2Locy) - handles.upperBoxSize/2;
handles.match2LowerBound = 3/4*(2*handles.height-handles.match2Locy) + handles.upperBoxSize/2;
handles.match3UpperBound = 3/4*(2*handles.height-handles.match3Locy) - handles.upperBoxSize/2;
handles.match3LowerBound = 3/4*(2*handles.height-handles.match3Locy) + handles.upperBoxSize/2;
handles.sampleLeftBound = (3/4)*(handles.sampleLocx) - handles.sampleBoxSize/2;
handles.sampleRightBound = (3/4)*(handles.sampleLocx) + handles.sampleBoxSize/2;
handles.sampleUpperBound = 3/4*(2*handles.height-handles.sampleLocy) - handles.sampleBoxSize/2;
handles.sampleLowerBound = 3/4*(2*handles.height-handles.sampleLocy) + handles.sampleBoxSize/2;
handles.fixLeftBound = (3/4)*(handles.fixLocx) - handles.fixBoxSize/2;
handles.fixRightBound = (3/4)*(handles.fixLocx) + handles.fixBoxSize/2;
handles.fixUpperBound = 3/4*(2*handles.height-handles.fixLocy) - handles.fixBoxSize/2;
handles.fixLowerBound = 3/4*(2*handles.height-handles.fixLocy) + handles.fixBoxSize/2;
fLB = handles.fixLeftBound; 
fRB = handles.fixRightBound;
fLoB = handles.fixLowerBound; fUB = handles.fixUpperBound;
m1LB = handles.match1LeftBound; m1RB = handles.match1RightBound;
m2LB = handles.match2LeftBound; m2RB = handles.match2RightBound;
m3LB = handles.match3LeftBound; m3RB = handles.match3RightBound;
m1LoB = handles.match1LowerBound; m2LoB = handles.match2LowerBound;
m1UB = handles.match1UpperBound; m2UB = handles.match2UpperBound;
m3LoB = handles.match3LowerBound; m3UB = handles.match3UpperBound; %
sLB = handles.sampleLeftBound; sRB = handles.sampleRightBound;
sLoB = handles.sampleLowerBound; sUB = handles.sampleUpperBound;
fixX = [fLB fLB fRB fRB fLB];
fixY = [fLoB fUB fUB fLoB fLoB];
x1Data = [m1LB m1LB m1RB m1RB m1LB];
x2Data = [m2LB m2LB m2RB m2RB m2LB];
x3Data = [m3LB m3LB m3RB m3RB m3LB];
y1Data = [m1LoB m1UB m1UB m1LoB m1LoB];
y2Data = [m2LoB m2UB m2UB m2LoB m2LoB];
y3Data = [m3LoB m3UB m3UB m3LoB m3LoB]; %
sX = [sLB sLB sRB sRB sLB];
sY = [sLoB sUB sUB sLoB sLoB];
%for i = 1:5
 %   y1Data(i) = y1Data(i);
 %   y2Data(i) = y2Data(i);
 %   y3Data(i) = y3Data(i); %
 %   fixY(i) = fixY(i);
%end
set(handles.matchBox1,'XData',x1Data,'YData',y1Data);
set(handles.matchBox2,'XData',x2Data,'YData',y2Data);
set(handles.matchBox3,'XData',x3Data,'YData',y3Data);
set(handles.fixBox,'XData',fixX,'YData',fixY);
set(handles.sampleBox,'XData',sX,'YData',sY);

function handles = createPath(handles)
num = 1;
subNum = handles.subNum;
c = clock;
directory = ['C:\Documents and Settings\admin\Desktop\colorProgVer3b\data\subject' num2str(subNum) '\' num2str(c(1)) '\' num2str(c(2)) '\' num2str(c(3)) '\cycle' num2str(num)];
while (isdir(directory))
    num = num + 1;
    directory = (['C:\Documents and Settings\admin\Desktop\colorProgVer3b\data\subject' num2str(subNum) '\' num2str(c(1)) '\' num2str(c(2)) '\' num2str(c(3)) '\cycle' num2str(num)]);
end
handles.cycleNum = num;
mkdir(directory);
cd(directory);
handles.directory = directory;

function handles = updateHandles(handles, nt, e, f)
handles = currentEyePos(handles);
% handles = checkEyePosition(handles);
callbacks = guidata(gcbo);
callbacks.count = handles.count;
callbacks.stimuliRecord = handles.stimuliRecord;
callbacks.responses = handles.responses;
if strcmp(e,'erase')
    callbacks.stimuliChanges = [];
end
callbacks.trialsToComplete = handles.trialsToComplete;
callbacks.eyex = handles.eyex;
callbacks.eyey = handles.eyey;
callbacks.eyePos = handles.eyePos;
callbacks.eyeCount = handles.eyeCount;
callbacks.eyeStore = handles.eyeStore;
callbacks.eyeCurrent = handles.eyeCurrent;
callbacks.sec2time = handles.sec2time;
callbacks.matchMX = handles.matchMX;
    %disp(['callbacks.matchMX: ' num2str(callbacks.matchMX)]);

if ~handles.allOK
    callbacks.allOK = 0;
end
if strcmp(nt,'new trial')
    callbacks.allOK = 1;
end
callbacks.eyeIsFixed = handles.eyeIsFixed;
if ~handles.eyeIsFixed
    callbacks.allOK = 0;
end
if strcmp(f,'finish')
    callbacks.finish = 0;
end
handles = callbacks;

function [r g b] = colorFind(colorNum, max)
colors = [243.4873  139.5029  143.2699
  239.8191  143.1195  130.2156
  233.2446  147.6548  117.3788
  224.1444  152.6779  105.5389
  212.8438  157.8453   95.8461
  199.6089  162.8962   89.9811
  184.6566  167.6314   89.5844
  168.1752  171.8916   94.7389
  150.3598  175.5377  103.8584
  131.4764  178.4363  115.2153
  112.0043  180.4512  127.6322
   93.0781  181.4407  140.3480
   78.4154  181.2639  152.7954
   78.6703  179.7964  164.4665
   94.9924  176.9598  174.8522
  117.2294  172.7621  183.4328
  141.1219  167.3457  189.7070
  164.7342  161.0283  193.2514
  186.6833  154.3180  193.7900
  205.8668  147.8806  191.2510
  221.4798  142.4463  185.7856
  233.0566  138.6602  177.7419
  240.4632  136.9222  167.6040
  243.8353  137.2891  155.9237
  230.1619  145.7388  144.5423
  227.6129  148.1541  135.0262
  222.6745  151.3356  125.9614
  215.6390  154.9905  118.0162
  206.7976  158.8561  111.9495
  196.4383  162.7102  108.5220
  184.8592  166.3684  108.2563
  172.3994  169.6757  111.1735
  159.4932  172.4967  116.7808
  146.7572  174.7086  124.3296
  135.1226  176.1965  133.0699
  125.9752  176.8543  142.3520
  121.1044  176.5904  151.6219
  122.0484  175.3412  160.3876
  129.0200  173.0892  168.1936
  140.7337  169.8877  174.6165
  155.3077  165.8839  179.2808
  170.9893  161.3338  181.8889
  186.3529  156.5994  182.2572
  200.2971  152.1177  180.3433
  212.0238  148.3414  176.2553
  221.0218  145.6588  170.2399
  227.0407  144.3175  162.6530
  230.0460  144.3815  153.9264
  215.9391  151.6381  145.7985
  214.3966  153.0602  139.6740
  211.1149  155.0276  133.9733
  206.2933  157.3704  129.1249
  200.1643  159.9184  125.5402
  192.9914  162.5115  123.5597
  185.0752  165.0056  123.3845
  176.7694  167.2728  125.0243
  168.5017  169.2005  128.2962
  160.7967  170.6897  132.8754
  154.2832  171.6557  138.3649
  149.6586  172.0291  144.3516
  147.5777  171.7619  150.4353
  148.4676  170.8339  156.2419
  152.3560  169.2627  161.4283
  158.8346  167.1136  165.6894
  167.1791  164.5061  168.7695
  176.5314  161.6155  170.4770
  186.0478  158.6642  170.6997
  194.9881  155.9013  169.4157
  202.7603  153.5729  166.6976
  208.9373  151.8869  162.7073
  213.2534  150.9820  157.6845
  215.5878  150.9105  151.9314
  200.5899  157.2523  147.0392
  199.9260  157.8572  144.1844
  198.3391  158.7367  141.5713
  195.9298  159.8222  139.3888
  192.8357  161.0365  137.8005
  189.2276  162.2989  136.9290
  185.3063  163.5304  136.8422
  181.3000  164.6569  137.5452
  177.4595  165.6117  138.9799
  174.0494  166.3380  141.0331
  171.3325  166.7901  143.5496
  169.5451  166.9363  146.3480
  168.8666  166.7606  149.2352
  169.3877  166.2658  152.0193
  171.0891  165.4749  154.5201
  173.8380  164.4327  156.5783
  177.4034  163.2050  158.0636
  181.4881  161.8761  158.8816
  185.7654  160.5426  158.9793
  189.9137  159.3060  158.3488
  193.6444  158.2623  157.0281
  196.7207  157.4926  155.0993
  198.9671  157.0539  152.6841
  200.2730  156.9746  149.9375
  185.5285  162.0944  148.1431
  178.5658  155.5562  141.8608
  192.6378  168.7836  154.5474];  

gray = 97; % neutral gray is at row 97 in matrix
if max > 0
    rows = [73 49 25 1];
    %order = [0 5 1 2 4 3 6];
    %r = colors(rows(max)+order(colorNum),1);
    r = colors(rows(max)+colorNum-1,1);
    g = colors(rows(max)+colorNum-1,2);
    b = colors(rows(max)+colorNum-1,3);
else
    r = colors(gray,1); g = colors(gray,2); b = colors(gray,3);
end
%disp(['match colors: ' num2str([r g b])]);






