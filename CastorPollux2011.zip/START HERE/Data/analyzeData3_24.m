function [A C1 C2 C3 C4 C5 C6 C7 C8 C9 C10 C11 C12 C13 C14 C15 C16 C17 C18 C19 C20 C21 C22 C23 C24] = analyzeData3_24(resultsFile)
               
answer = 0; %= input('Display all graphs? [1 for yes, 0 for no]  ');


% [eyeTime eyeX eyeY] = textread(eyeFile,'%f %f %f','headerlines',15);  %13 change to 19 by rosa
% eyeData = [eyeTime eyeX eyeY];
% eyeData is now an array containing:
%     [  Time(sec.)    X Position    Y Position  ]
% for the entire session

numTrialsPerCycle = 552;
[A B C D E F G H I] = textread(resultsFile,'%u %f %f %f %u %u %u %u %u',552,...
                   'headerlines',(19));
trialInfo = [A B C D E F G H I];
compBias = mean(H)

%trialInfo is now an array containing:
% [Trialcount RedAmount GreenAmount BlueAmount sample# saturationLevel
% comparedTo corrMatchLoc incorrMatchLoc]
               
[a b c d e f g h i] = textread(resultsFile,'%u %u %u %u %f %u %f %u %f',...
                   'headerlines',(19 + numTrialsPerCycle + 3));
results = [a b c d e f g h i];
% results is now an array containing:
%     [  TrialNumber     HueNumber                SaturationAmount ...
%        CompareNumber   TimeOfMatchPresentation  HueChosen ...
%        TimeOfResponse  Correct?(bool) sec2time ]
% for each trial (completed and uncompleted)
totalTrials = length(results)
missTrials = totalTrials-552

% this array contains results for complete AND incomplete (due to
% breaks in fixation, etc.) trials. Incomplete trials have '9999' in 
% the sixth and eighth columns. this data is stored in the text file, so
% we'll get rid of the rows containing '9999'. 

results = results(results(:,8)~=9999,:);

% find percent correct
A = sum(results(:,8))/length(results)*100;
disp(['overall percent correct for this cycle: ' num2str(A)])
%disp(['Percent correct equals ' num2str(sum(results(:,8))/length(results)*100)]);

% now results has only completed trials (but remember that the trial
% numbers are now no longer organized and may repeat if there are 
% multiple cycles in the session)

% now break results up based on hue of sample (column two) (including
% gray--saturation of 0)

c1 = results(results(:,2) == 1,:)
c2 = results(results(:,2) == 2,:)
c3 = results(results(:,2) == 3,:);
c4 = results(results(:,2) == 4,:); 
c5 = results(results(:,2) == 5,:);
c6 = results(results(:,2) == 6,:);
c7 = results(results(:,2) == 7,:);
c8 = results(results(:,2) == 8,:);
c9 = results(results(:,2) == 9,:);
c10 = results(results(:,2) == 10,:);
c11 = results(results(:,2) == 11,:);
c12 = results(results(:,2) == 12,:);
c13 = results(results(:,2) == 13,:);
c14 = results(results(:,2) == 14,:);
c15 = results(results(:,2) == 15,:);
c16 = results(results(:,2) == 16,:);
c17 = results(results(:,2) == 17,:);
c18 = results(results(:,2) == 18,:);
c19 = results(results(:,2) == 19,:);
c20 = results(results(:,2) == 20,:);
c21 = results(results(:,2) == 21,:);
c22 = results(results(:,2) == 22,:);
c23 = results(results(:,2) == 23,:);
c24 = results(results(:,2) == 24,:);

C1 = mean(c1(:,8))*100;
C2 = mean(c2(:,8)*100);
C3 = mean(c3(:,8)*100);
C4 = mean(c4(:,8)*100);
C5 = mean(c5(:,8)*100);
C6 = mean(c6(:,8)*100);
C7 = mean(c7(:,8)*100);
C8 = mean(c8(:,8)*100);
C9 = mean(c9(:,8)*100);
C10 = mean(c10(:,8)*100);
C11 = mean(c11(:,8)*100);
C12 = mean(c12(:,8)*100);
C13 = mean(c13(:,8)*100);
C14 = mean(c14(:,8)*100);
C15 = mean(c15(:,8)*100);
C16 = mean(c16(:,8)*100);
C17 = mean(c17(:,8)*100);
C18 = mean(c18(:,8)*100);
C19 = mean(c19(:,8)*100);
C20 = mean(c20(:,8)*100);
C21 = mean(c21(:,8)*100);
C22 = mean(c22(:,8)*100);
C23 = mean(c23(:,8)*100);
C24 = mean(c24(:,8)*100);

A = mean(results(:,8));

