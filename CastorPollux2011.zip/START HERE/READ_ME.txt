Please read the attached Overview.doc file for description of data files, stimulus info, and task info. This overview pertains to all data collected starting on 12/18/2009. 

Please take NOTE:  The animals began training on the task in late August 2009. However, the program was modified frequently betwen september and December 18, 2009, when the final standardized version went into use.

	The most notable changes leading up to this version:
	- the original task only used 7 colors (the final version 				uses 24)
	- in the original task there were only 2 locations where the 
		matches could appear, the final version had 3
	- a presentation bias was introduced during the 					addition of the third location site and was removed				sometime later 
	- a new monitor was installed and a new stimulus set 				was calibrated on 12/18/2009

The point is, any data previous to 12/18/2009 should be analyzed separately from all data post 12/18/2009, and should be analyzed given the above understandings. For this reason, the data folder I am providing you with only contains data starting on 12/18/2010.

Please contact me if you are interested in the pre 12/18/2009 data, as it will require combing through my notes and the six or so different versions of the program.  








