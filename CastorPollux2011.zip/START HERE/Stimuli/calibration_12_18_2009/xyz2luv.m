function [luv,uprime,vprime] = xyz2luv(xyz,obs)

% function [luv,uprime,vprime] = xyz2luv(xyz,obs)
% computes CIELUV Luv values from XYZ tristimulus values
% uprime and vprime are the CIE 1976 UCS coordinates
% requires the illuminant/observer obs to define white point
% see function r2xyz for valid values for obs
% 5th April 2004 - typo corrected for d50_31
% 1st December 2004 - F9 corrected to read F11
% 10th December 2004 - Xn for ill A (1931) corrected to 109.850


if strcmp('a_64',obs)
    white=[111.144 100.00 35.200];
elseif strcmp('a_31', obs)
    white=[109.850 100.00 35.585];
elseif strcmp('c_64', obs)
    white=[97.285 100.00 116.145];
elseif strcmp('c_31', obs)
    white=[98.074 100.00 118.232];
elseif strcmp('d50_64', obs)
    white=[96.720 100.00 81.427];
elseif strcmp('d50_31', obs)
    white=[96.422 100.00 82.521];
elseif strcmp('d55_64', obs)
    white=[95.799 100.00 90.926];
elseif strcmp('d55_31', obs)
    white=[95.682 100.00 92.149];
elseif strcmp('d65_64', obs)
    white=[94.811 100.00 107.304];
elseif strcmp('d65_31', obs)
    white=[95.047 100.00 108.883];
elseif strcmp('d75_64', obs)
    white=[94.416 100.00 120.641];
elseif strcmp('d75_31', obs)
    white=[94.072 100.00 122.638];
elseif strcmp('f2_64', obs)
    white=[103.279 100.00 69.027];
elseif strcmp('f2_31', obs)
    white=[99.186 100.00 67.393];
elseif strcmp('f7_64', obs)
    white=[95.792 100.00 107.686];
elseif strcmp('f7_31', obs)
    white=[95.041 100.00 108.747];
elseif strcmp('f11_64', obs)
    white=[103.863 100.00 65.607]; 
elseif strcmp('f11_31', obs)
    white=[100.962 100.00 64.350];
elseif strcmp('Conway_07', obs) %added to accomodate BRC-defined white point from Conway et al., 2007
    white=[3.0694 3.05 3. 5939];%calculated XYZ values from xyY: .316 .314 3.05
elseif strcmp('june09',obs) %stimuli for summer '09
    white = [44.10	47.20	68.25]; %reading taken 4/3/09 ([140 140 140])
elseif strcmp('15june09',obs) %reading from 6/15/09
    white = [43.79 46.75 68.45];
elseif strcmp('13dec09',obs) %reading from new barco HMS dec 09
    white = [31.76972826	34.16	50.10288043];  
elseif strcmp('16dec09',obs) %reading from new barco HMS dec 09
    white = [16.77055724	18.11	26.28121243]; 
else
   disp('unknown option obs'); 
   disp('use d65_64 for D65 and 1964 observer'); return;
end

dim = size(xyz);
if (dim(1) == 1) | (dim(2) == 1)
   xyz = xyz(:)'; % force to be a row matrix
else
   disp('xyz must be a row matrix');
   return;
end


% compute u' v' for sample
uprime = 4*xyz(1)/(xyz(1) + 15*xyz(2) + 3*xyz(3));
vprime = 9*xyz(2)/(xyz(1) + 15*xyz(2) + 3*xyz(3));
% compute u' v' for white
uprimew = 4*white(1)/(white(1) + 15*white(2) + 3*white(3));
vprimew = 9*white(2)/(white(1) + 15*white(2) + 3*white(3));

if (xyz(2)/white(2) > 0.008856)
   luv(1) = 116*(xyz(2)/white(2))^(1/3) - 16;  
else
   luv(1) = 903.3*(xyz(2)/white(2));   
end

luv(2) = 13*luv(1)*(uprime - uprimew);
luv(3) = 13*luv(1)*(vprime - vprimew);


















