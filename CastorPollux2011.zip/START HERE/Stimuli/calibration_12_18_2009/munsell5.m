% for a new monitor, update lines 8 and 24
% line 8: create a new Barco1.m file using the spectral readings from your
% monitor
% line 24: in the file xyz2luv.m, add a line corresponding to the
% whitepoint (neutral) for your monitor. for instance, rgb 
% values [140 140 140]

[gogvals A] = BarcoRosa2; % update this line to match the function you construct 
                      % for your monitor

xyCoords = [
    0.5020 0.3212 30.050;  % red
    0.4905 0.5038 30.050;  % yellow
    0.2130 0.4571 30.050;  % green
    0.1496 0.2193 30.050;  % blue
    0.1662 0.3343 30.050;  % cyan
    0.5488 0.3947 30.050;  % orange
    0.2794 0.1979 30.050;  % purple
    0.4023 0.2552 30.050]; % magenta

for i=1:8
    [X Y Z] = xyY2XYZ(xyCoords(i,1),xyCoords(i,2),xyCoords(i,3));
    %equirgb(i,:) = xyz2srgb([X; Y; Z]);%, gogvals, A);
    [equiluv(i,:) uprime(i), vprime(i)] = xyz2luv([X Y Z],'16dec09'); 
                            % update using new white point
end

% find ideal whitepoint (allows for largest radius)
xvals = linspace(-50,150,200);
yvals = linspace(-75,75,200);
for j = 1:length(xvals)
    for k = 1:length(yvals)
        for i=1:length(equiluv)
            dist(j,k,i) = sqrt((equiluv(i,2)-xvals(j))^2+(equiluv(i,3)-yvals(k))^2);
        end
    end
end
minimum = min(dist,[],3);
[max1 j1] = max(minimum,[],1);
[max2 k1] = max(max1);
ycent = yvals(k1);
xcent = xvals(j1(k1));
r = minimum(j1(k1),k1);

luminance = min(equiluv(:,1));

%figure
% find angles - every 15 degrees

angle = [];
for i=0:15:345
    angle = [angle i];
end

% find points in luv space of concentric circles (3 sets of 7 colors and 
% three grays (one equiluminant to the sets, one lighter and one darker))
% using hue angles equally spaced

% set 1
radius = r*6/12+.15*r;
for i=1:length(angle)
    set1(i,:) = [radius*cosd(angle(i))+xcent radius*sind(angle(i))+ycent];
end
%set1 = set1(order,:);

% set 2
radius = r*4/12+.15*r;
for i=1:length(angle)
    set2(i,:) = [radius*cosd(angle(i))+xcent radius*sind(angle(i))+ycent];
end
%set2 = set2(order,:);

% set 3
radius = r*2/12+.15*r;
for i=1:length(angle)
    set3(i,:) = [radius*cosd(angle(i))+xcent radius*sind(angle(i))+ycent];
end
%set3 = set3(order,:);

% set 4
radius = r*.15;
for i=1:length(angle)
    set4(i,:) = [radius*cosd(angle(i))+xcent radius*sind(angle(i))+ycent];
end
%set4 = set4(order,:);

% gray
gray = [xcent ycent];

luvcoords = [set1; set2; set3; set4; gray];

% convert to xyz    
LAst = luminance; % the colors from set 3 are equiluminant in munsell space, 
                  % but not once you convert to LUV. so, I'm using the
                  % lowest luminance here
Xn = 16.77055724; Yn = 18.11; Zn = 26.28121243; %vals from 12/16 new barco rosa Xn = 31.76972826;Yn = 34.16;Zn = 50.10288043; %readings from dec 13th 09 %Xn = 43.79; Yn = 46.75; Zn = 68.45; %readings from june 15th
uPn = (4*Xn)/(Xn + 15*Yn + 3*Zn);
vPn = (9*Yn)/(Xn + 15*Yn + 3*Zn);
    
for i=1:length(luvcoords)
    uAst = luvcoords(i,1);
    vAst = luvcoords(i,2);

    uP = uAst/(13*LAst) + uPn;
    vP = vAst/(13*LAst) + vPn;

    Y = Yn*((LAst+16)/116)^3; %LAst greater than 8
    X = Y*((9*uP)/(4*vP));
    Z = Y*((12-3*uP-20*vP)/(4*vP));
    xyz(i,:) = [X Y Z];
end

% convert to rgb
rgb = zeros(length(xyz),3);
for i=1:length(rgb)
    rgb(i,:) = xyz2rgb(xyz(i,:)',gogvals,A);
end
rgb

% dark gray
LAst = luminance-5;
Xn = 16.77055724; Yn = 18.11; Zn = 26.28121243; %vals from 12/16 new barco rosa %Xn = 31.76972826;Yn = 34.16;Zn = 50.10288043; %readings from dec 13th 09 %Xn = 43.79; Yn = 46.75; Zn = 68.45; %readings from june 15th
uPn = (4*Xn)/(Xn + 15*Yn + 3*Zn); vPn = (9*Yn)/(Xn + 15*Yn + 3*Zn);
uAst = luvcoords(97,1);
vAst = luvcoords(97,2);
uP = uAst/(13*LAst) + uPn;
vP = vAst/(13*LAst) + vPn;
Y = Yn*((LAst+16)/116)^3; %LAst greater than 8
X = Y*((9*uP)/(4*vP));
Z = Y*((12-3*uP-20*vP)/(4*vP));
darkgrayxyz = [X Y Z];
darkgrayrgb = xyz2rgb(darkgrayxyz',gogvals,A)
    
% light gray
LAst = luminance+5;
Xn = 16.77055724; Yn = 18.11; Zn = 26.28121243; %vals from 12/16 new barco rosa %Xn = 31.76972826;Yn = 34.16;Zn = 50.10288043; %readings from dec 13th 09 %Xn = 43.79; Yn = 46.75; Zn = 68.45; %readings from june 15th
uPn = (4*Xn)/(Xn + 15*Yn + 3*Zn); vPn = (9*Yn)/(Xn + 15*Yn + 3*Zn);
uAst = luvcoords(97,1);
vAst = luvcoords(97,2);
uP = uAst/(13*LAst) + uPn;
vP = vAst/(13*LAst) + vPn;
Y = Yn*((LAst+16)/116)^3; %LAst greater than 8
X = Y*((9*uP)/(4*vP));
Z = Y*((12-3*uP-20*vP)/(4*vP));
lightgrayxyz = [X Y Z];
lightgrayrgb = xyz2rgb(lightgrayxyz',gogvals,A)

swatches = figure;
set(gcf,'Color',[1 1 1]);
for i=1:length(rgb)-1
    subplot(5,24,i)
    set(gca,'Color',rgb(i,:)./255,'XColor',[1 1 1],'YColor',[1 1 1]);
end
subplot(5,24,24*4+1);
set(gca,'Color',lightgrayrgb./255,'XColor',[1 1 1],'YColor',[1 1 1]);
subplot(5,24,24*4+2);
set(gca,'Color',darkgrayrgb./255,'XColor',[1 1 1],'YColor',[1 1 1]);
subplot(5,24,24*4+3);
set(gca,'Color',rgb(97,:)./255,'XColor',[1 1 1],'YColor',[1 1 1]);

