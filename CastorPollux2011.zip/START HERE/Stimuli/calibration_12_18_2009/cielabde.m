function [de,dl,dc,dh] = cielabde(lab1,lab2)

% function [de,dl,dc,dh] = cielabde(lab1,lab2)
% computes colour difference from CIELAB values
% using CIELAB formula
% lab1 and lab2 must be 3 by 1 or 1 by 3 matrices
% and contain L*, a* and b* values
% see also cmcde, cie94de, and cie00de

dim = size(lab1);
if (dim(1) == 1) | (dim(2) == 1)
   lab1 = lab1(:)'; % force to be a row matrix
else
   disp('lab1 must be a row matrix');
   return;
end
if (dim(2) ~= 3)
   disp('lab1 must be 3 by 1 or 1 by 3');
   return;
end

dim = size(lab2);
if (dim(1) == 1) | (dim(2) == 1)
   lab2 = lab2(:)'; % force to be a row matrix
else
   disp('lab2 must be a row matrix');
   return;
end
if (dim(2) ~= 3)
   disp('lab2 must be 3 by 1 or 1 by 3');
   return;
end

dl = lab2(1)-lab1(1);

dc = sqrt(lab2(2)^2 + lab2(3)^2) - sqrt(lab1(2)^2 + lab1(3)^2);
dh = sqrt((lab2(2)-lab1(2))^2 + (lab2(3)-lab1(3))^2 - dc^2);

% get the polarity of the dh term
dh = dh*dhpolarity(lab1,lab2);

de = sqrt(dl^2 + dc^2 + dh^2);

















