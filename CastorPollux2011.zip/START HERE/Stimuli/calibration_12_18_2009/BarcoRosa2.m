function [gogvals A] = BarcoRosa2

% now a function for use in 'colorstim.m'

%cd C:\research\monitor_calib\westland
%clear all
%close all

%the Yxy values from germany
% red (255, 0, 0): 	15.5 	.614 	.353
% green(0, 255, 0):	 53.9 	.287 	.6
% blue (0, 0, 255):	7.68	.144	.064

%ROSA's vals 12/13/09
r = [255, 0, 0, 30.76776199,	16.5,	1.577708703];
g = [0	255	0,	29.97500911,	63.03,	11.40115289];
b = [0	0	255,	22.3397648,	9.377,	118.3152352];

%define the dac RGB and XYZ values of the neutral samples

N = [70,	70,	70,	1.300741731,	1.408,	1.995568326;...
90,	90,	90,	3.741794958,	4.045,	5.809843697;...
140,	140,	140,	16.77055724,	18.11,	26.28121243;...
190,	190,	190,	40.29075804,	43.31,	62.96438579;...
240,	240,	240,	73.04795808,	78.26,	113.2626978];


% define the dac RGB and XYZ of the test samples; Cleo took 18 total, but
% the program can only handle 7 at a time.
%%ROSA'a:
% T = [200 200 100 64.9698035	81.96	30.05141006; 100 100 200 30.08083832	19.7	118.7392643;...
%     200 100 50 34.13079008	24.43	3.904052672; 25 150 250 52.83022059	45.87	207.9174265;...
%     250 50 25 53.50690652	29.04	3.091548216; 175 250 50 72.58387792	118.7	21.82204668;...
%     75 25 125 9.442309004 17.69	3.034812415];
  %next 7:
  T = [200	200	100	34.09161091	43.37	14.95262306;...
100	100	200	15.78561189	10.22	63.33005245;...
200	100	50	18.1531746	12.85	1.894930876;...
25	150	250	28.44279452	24.37	114.1050137;...
250	50	25	29.43086726	15.92	1.610784661;...
175	250	50	40.28047449	66.69	11.99135212;...
50	25	75	0.525240701	0.2302	2.346985175];

%%CLEO's:
% %first 7
% T = [20 200 200 66.71 92.42 163.3; 200 20 200 68.38 33.42 152; 200 200 20 77.78 100.9 16.12; ...
%     50 150 250 67.61 60.57 256.7; 150 50 250 67.13 31.41 248.7; 250 150 50 87.26 76.51 13.41; ...
%     50 250 150 77.86 139 98.62];
% %next 7
% % T = [250 50 150 82.38 43.91 78.26; 150 250 50 81.54 140.5 27.37; 10 100 100 11.69 16.06 28.22; ...
% %     100 10 100 11.40 5.725 26.25; 100 100 10 13.11 17.36 3.013; 25 75 125 11.98 9.987 4.802; ...
% %     75 25 125 11.87 5.517 47.36];
% %the last 7 (note the first three are repeats from above)
% T = [100 100 10 13.11 17.36 3.013; 25 75 125 11.98 9.987 48.02; 75 25 125 11.87 5.517 47.36; ...
%     125 75 25 14.81 12.56 2.118; 25 125 75 14.48 26.39 15.92; 25 75 125 14.06 7.514 12.33; ...
%     75 125 25 15.05 26.91 4.891];


%specify the matrix A to convert RGB to XYZ
A = [r(4) g(4) b(4); r(5) g(5) b(5); r(6) g(6) b(6)];

%compute the matrix AI to convert XYZ to RGB
AI=inv(A);

%obtain the XYZ values of the neutral patches
NXYZ=N(:, 4:6);

%compute the RGB values of the neutral patches
NRGB=(AI*NXYZ')';

%obtain the normalized dac values of the neutral patches
DRGB = N(:, 1:3)/255;

%compute the GOG (gain offset gamma) values for each channel
%these are the values that effectively linearize the monitor
x1=linspace(0,1,10);

x=[1, 1];
options = optimset;
x=fminsearch('gogtest', x, options, DRGB(:,1), NRGB(:,1));
gogvals(1,:)=x;%the two values of x are the gamma and the gain
%figure
%plot(DRGB(:,1), NRGB(:,1), 'r*')
y1=compgog(gogvals(1,:), x1);
%hold on
%plot(x1, y1, 'r-')

x=[1, 1];
options = optimset;
x=fminsearch('gogtest', x, options, DRGB(:,2), NRGB(:,2));
gogvals(2,:)=x;%the two values of x are the gamma and the gain
%figure
%plot(DRGB(:,2), NRGB(:,2), 'g*')
y1=compgog(gogvals(2,:), x1);
%hold on
%plot(x1, y1, 'g-')

x=[1, 1];
options = optimset;
options.TolFun=0.0000001;
x=fminsearch('gogtest', x, options, DRGB(:,3), NRGB(:,3));
gogvals(3,:)=x;%the two values of x are the gamma and the gain
%figure
%plot(DRGB(:,3), NRGB(:,3), 'b*')
y1=compgog(gogvals(3,:), x1);
%hold on
%plot(x1, y1, 'b-')

%disp('gogvals')
%disp(gogvals)

RGB = zeros(3+length(N(:,1)),3);
RDACS=[r(1); g(1); b(1); N(:,1)]/255;
RGB(:,1)=compgog(gogvals(1,:), RDACS);
RDACS=[r(2); g(2); b(2); N(:,2)]/255;
RGB(:,2)=compgog(gogvals(2,:), RDACS);
RDACS=[r(3); g(3); b(3); N(:,3)]/255;
RGB(:,3)=compgog(gogvals(3, :), RDACS);
RGB;
XYZ =(A*RGB')';

AXYZ=[r(4:6); g(4:6); b(4:6); N(:, 4:6)];

% for i=1:8 %changed from 1:8
%     [lab1]=xyz2lab(XYZ(i,:), 'd65_64');
%     [lab2]=xyz2lab(AXYZ(i,:), 'd65_64');
%     [thisDE]=cielabde(lab1,lab2);
%     de(i)=thisDE;
% end

%disp('known values')
%disp(de)

RGB=zeros(length(T(:,1)),3);
RDACS=[T(:,1)]/255;
RGB(:,1)=compgog(gogvals(1,:), RDACS);
RDACS=[T(:,2)]/255;
RGB(:,2)=compgog(gogvals(2,:), RDACS);
RDACS=[T(:,3)]/255;
RGB(:,3)=compgog(gogvals(3,:), RDACS);

XYZ=(A*RGB');

AXYZ=[T(:, 4:6)];
clear de
% 
% % now compute the error for the test samples
% for i= 1:8
%     [lab1]=xyz2lab(XYZ(i,:), 'd65_64');
%     [lab2]=xyz2lab(AXYZ(i,:), 'd65_64');
%     [thisDE]=cielabde(lab1,lab2);
%     de(i)=thisDE;
% end

%disp('test values')
%disp(de)



































