function [XYZ] = rgb2xyz(dacs,gogs,A)

dacs=dacs(:)';
if (lenth(dacs)~=3)
    disp('DACS must be 3 by 1 or 1 by 3'); return;
end

dacs = dacs/255;

RGB(1) = compgog(gogs(1,:),dacs(1));
RGB(2) = compgog(gogs(2,:),dacs(2));
RGB(3) = compgog(gogs(3,:),dacs(3));

RGB(=RGB(:);

XYZ=A*RGB;
