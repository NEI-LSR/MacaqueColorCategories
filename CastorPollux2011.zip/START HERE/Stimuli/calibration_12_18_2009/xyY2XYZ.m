function [X Y Z] = xyY2XYZ (x, y, Y)
%converts CIE xyY data into XYZ data, Bevil Conway May 29, 2009
%equations from Westland's book pg. 59

X=(Y/y)*x;
Y=Y;
Z=(Y/y)*(1-x-y);

%XYZ = [X Y Z];














