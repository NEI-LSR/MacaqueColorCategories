function [rgb] = compgog(gogs,dacs)

% function [rgb] = compgog(gogs,dacs)
% computes the linearized RGB values  
% from the normalized RGB values 
% for a given set of gog values
% gog is a 2 by 1 matrix that contains the gamma and gain
% dacs is an n by 1 matrix that contains the RGB values
% rgb is an n by 1 matrix of linearized RGB values 

gamma = gogs(1);
gain = gogs(2);
for i=1:length(dacs)
   if (gain*dacs(i) + (1-gain)) <= 0
      rgb(i)=0;      
   else
      rgb(i)=(gain*dacs(i) + (1-gain))^gamma;    
   end
end
% force output to be a column vector
rgb=rgb(:);
