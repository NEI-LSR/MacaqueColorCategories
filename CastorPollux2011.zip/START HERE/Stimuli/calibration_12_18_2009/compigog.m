function [dacs] = compigog(gogs,rgb)

% function [dacs] = compgog(gogs,rgb)
% computes the normalized RGB values  
% from the linearized RGB values 
% for a given set of gog values
% gog is a 2 by 1 matrix that contains the gamma and gain
% dacs is an n by 1 matrix that contains the RGB values
% rgb is an n by 1 matrix of linearized RGB values 

gamma = gogs(1);
gain = gogs(2);
for i=1:length(rgb)
   dacs(i)=((rgb(i)^(1/gamma)) - (1-gain))/gain;    
end
% force output to be a column vector
rgb=rgb(:);
