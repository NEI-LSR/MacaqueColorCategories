function [err] = gogtest(gogs,dacs,rgbs)

% function [err] = gogtest(gogs,dacs,rgbs)
% computes the error between measured and predicted 
% linearized dac values for a given set of GOG values
% gogs is a 2 by 1 matrix that contains the gamma and gain
% dacs is an n by 1 matrix that contains the actual RGB values
% obtained by dividing the RGB values by 255
% rgbs is an n by 1 matrix that is obtained from a linear 
% transform of measured XYZ values

gamma = gogs(1);
gain = gogs(2);

% force to be row matrices
dacs = dacs(:)';
rgbs = rgbs(:)'; 

if (length(dacs) ~= length(rgbs))
   disp('dacs and rgbs vectors must be the same length'); 
   err = 0;
   return
end

% compute gog model predictions
for i=1:length(dacs)
   if (gain*dacs(i) + (1-gain)) <= 0
      pred(i)=0;      
   else
      pred(i)=(gain*dacs(i) + (1-gain))^gamma;    
   end
end

% force to be a row matrix
pred = pred(:)';
% compute rms error
err = sqrt((sum((rgbs-pred).*(rgbs-pred)))/length(dacs));

